# Flexware Front-End

This is a front-end interface for the solution that facilitates the transfer of requests across systems on a Host-to-Host infrastructure
