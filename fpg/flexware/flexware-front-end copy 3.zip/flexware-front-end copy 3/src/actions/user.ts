import {
  LOG_USER_IN,
  SET_AUTH_TOKEN,
  AUTHORIZE,
  SET_VERIFIED,
  SET_USER_ID,
} from './types';
import asyncAction from '../utils/asyncAction';
import api from '../utils/api';

export const logUserIn = asyncAction(LOG_USER_IN, credentials =>
  api.post('/users/admin/login', credentials),
);

export const setAuthToken = (token: string) => ({
  type: SET_AUTH_TOKEN,
  payload: token,
});

export const setVerified = (payload: boolean) => ({
  type: SET_VERIFIED,
  payload,
});
export const setUid = (payload: string) => ({
  type: SET_USER_ID,
  payload,
});

export const authorize = asyncAction(AUTHORIZE, (credentials, token) => {
  localStorage.setItem('otp', credentials.otp);
  return api.post('/otp/validate', credentials, token);
});
