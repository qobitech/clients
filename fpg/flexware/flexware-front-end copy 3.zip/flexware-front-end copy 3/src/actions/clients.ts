import {
  ADD_CLIENT_SUCCEEDED,
  ADD_TO_COMPANY_LIST,
  REMOVE_LIVE_FROM_CLIENT,
  MAKE_CLIENT_LIVE,
  UPDATE_CARD_INFORMATION,
  SET_NUMBER_OF_CLIENTS,
} from './types';
import { ConfigTypes } from '../components/elements/ConfigurationsCard/types';

export const addClient = (data: any) => ({
  type: ADD_CLIENT_SUCCEEDED,
  payload: data,
});

export const addToCompanyList = (payload: any) => ({
  type: ADD_TO_COMPANY_LIST,
  payload,
});

export const toggleLiveClient = (payload: boolean) => {
  if (payload) {
    return { type: MAKE_CLIENT_LIVE };
  }
  return { type: REMOVE_LIVE_FROM_CLIENT };
};

export const updateCards = (payload: [ConfigTypes[], ConfigTypes[]]) => ({
  type: UPDATE_CARD_INFORMATION,
  payload,
});

export const setNumOfClients = (payload: number) => ({
  type: SET_NUMBER_OF_CLIENTS,
  payload,
});
