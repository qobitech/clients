/* eslint-disable import/no-cycle */
import * as actions from './types';
import { breadCrumbStackType } from '../reducers/app';
import asyncAction from '../utils/asyncAction';
import api from '../utils/api';

export const changeCurrentTab = (payload: any) => ({
  type: actions.SET_CURRENT_TAB,
  payload,
});

export const updateBreadCrumbStack = (payload: breadCrumbStackType) => {
  return {
    type: actions.UPDATE_BREAD_CRUMB_STACK,
    payload,
  };
};

export const updateComapnyDisplayed = (payload: string) => {
  return {
    type: actions.UPDATE_COMPANY_DISPLAYED,
    payload,
  };
};

export const showNotification = (payload: string) => {
  return {
    type: actions.SHOW_NOTIFICATION,
    payload,
  };
};

export const hideNotification = () => {
  return {
    type: actions.HIDE_NOTIFICATION,
    payload: '',
  };
};

export const logout = () => {
  return {
    type: actions.LOG_OUT,
  };
};

export const setWarningState = (state: boolean) => {
  if (state) {
    return {
      type: actions.START_TIMEOUT_WARNING,
    };
  }
  return {
    type: actions.STOP_TIMEOUT_WARNING,
  };
};

export const getCompany = asyncAction(actions.GET_CLIENT, (id, token) =>
  api.get(`/customers/find/${id}`, token),
);
