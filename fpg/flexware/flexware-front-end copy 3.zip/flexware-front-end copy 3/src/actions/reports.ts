import * as actions from './types';
import asyncAction from '../utils/asyncAction';
import api from '../utils/api';

export const getRecentTransactions = asyncAction(
  actions.GET_RECENT_CLIENTS,
  token => api.get('/transactions', token),
);
