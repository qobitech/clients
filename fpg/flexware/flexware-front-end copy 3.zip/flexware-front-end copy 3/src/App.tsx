import React from 'react';
import { BrowserRouter, Switch } from 'react-router-dom';
import Router from './components/Router';

function App() {
  return (
    <BrowserRouter basename={process.env.PUBLIC_URL}>
      <Switch>
        <Router />
      </Switch>
    </BrowserRouter>
  );
}

export default App;
