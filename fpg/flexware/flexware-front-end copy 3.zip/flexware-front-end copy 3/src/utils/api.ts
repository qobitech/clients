/* eslint-disable @typescript-eslint/no-explicit-any */
// import 'unfetch/polyfill';

type requestMethods = 'GET' | 'POST' | 'PUT';
const toJSON = (data: Response) => data.json();
const { REACT_APP_API_ROOT: API_ROOT } = process.env;
const requestOptions = (
  method: requestMethods,
  body?: RequestInit['body'],
  token?: string,
  header?: any,
): RequestInit => {
  const headers =
    header ||
    (token
      ? {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        }
      : {
          'Content-Type': 'application/json',
        });
  return body
    ? {
        method,
        body: JSON.stringify(body),
        headers,
      }
    : {
        method,
        headers,
      };
};

export default {
  get: (url: string, token?: string) =>
    fetch(API_ROOT + url, requestOptions('GET', '', token)).then(toJSON),
  post: (url: string, body: any, token?: string) =>
    fetch(API_ROOT + url, requestOptions('POST', body, token)).then(toJSON),
  put: (url: string, body: any, token?: string) =>
    fetch(API_ROOT + url, requestOptions('PUT', body, token)).then(toJSON),
};
export {};
