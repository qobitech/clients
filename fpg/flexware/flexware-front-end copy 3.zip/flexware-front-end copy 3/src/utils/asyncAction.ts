/* eslint-disable @typescript-eslint/no-explicit-any */
const asyncAction = (
  type: string,
  request: (...arg: any[]) => Promise<any>,
) => (...args: any[]): ((arg: any) => Promise<void>) => async (
  dispatch: any,
): Promise<void> => {
  dispatch({
    type: `${type}_REQUESTED`,
    request: { ...args },
  });

  try {
    const payload = await request(...args);
    if (payload.error) {
      dispatch({
        type: `${type}_FAILED`,
        request: { ...args },
        errors: [payload.message],
      });
      return Promise.resolve();
    }
    dispatch({
      type: `${type}_SUCCEEDED`,
      request: { ...args },
      payload,
    });
  } catch (error) {
    dispatch({
      type: `${type}_FAILED`,
      request: { ...args },
      errors: [error],
    });
  }
  return Promise.resolve();
};
export default asyncAction;
