/* eslint-disable import/no-cycle */
/* eslint-disable @typescript-eslint/camelcase */
// eslint-disable-next-line import/no-cycle
import { ReactElement, FunctionComponent, CSSProperties } from 'react';
// eslint-disable-next-line import/no-cycle
import { adminNavRoutes, clientNavRoutes, navRoutes } from '../reducers/app';
// eslint-disable-next-line import/no-cycle
import Reports from '../components/Dashboard/admin/Reports';
import Services from '../components/Dashboard/admin/Reports/Services';
// eslint-disable-next-line import/no-cycle
import Buisness from '../components/Dashboard/admin/Clients/Accounts/AccountsContainer';
// import Badge from '../components/elements/Badge';
import Contacts from '../components/Dashboard/admin/Clients/Contacts/ContactsContainer';
import { ConfigTypes } from '../components/elements/ConfigurationsCard/types';
import { ReactComponent as Dashboard } from '../components/Dashboard/SideNav/svgs/dashboard.svg';
import { ReactComponent as Clients } from '../components/Dashboard/SideNav/svgs/clients.svg';
import { ReactComponent as ReportsIcon } from '../components/Dashboard/SideNav/svgs/reports.svg';
import { ReactComponent as DocumentationIcon } from '../components/Dashboard/SideNav/svgs/file.svg';
import { ReactComponent as SettingsIcon } from '../components/Dashboard/SideNav/svgs/settings.svg';

export type navRouteDetailsTypes = {
  [key in navRoutes]: {
    title: string;
    url?: string;
    icon?: any;
  };
};

export type adminAavRouteDetailsTypes = {
  [key in adminNavRoutes]: {
    title: string;
    url?: string;
    icon?: any;
  };
};

export type clientNavRouteDetailsTypes = {
  [key in clientNavRoutes]: {
    title: string;
    url?: string;
    icon?: any;
  };
};

export const adminNavRouteOrder: Array<adminNavRoutes | navRoutes> = [
  'dashboard',
  'clients',
  'reports',
  'documentation',
  'settings',
];

export const clientNavRouteOrder: Array<clientNavRoutes | navRoutes> = [
  'dashboard',
  'upload',
  'integrations',
  'documentation',
  'settings',
];

export const navRouteDetails: navRouteDetailsTypes = {
  dashboard: { title: 'Dashboard', url: '/', icon: Dashboard },
  documentation: { title: 'Documentation', icon: DocumentationIcon },
  settings: { title: 'Settings', icon: SettingsIcon },
};

export const adminNavRouteDetails: adminAavRouteDetailsTypes = {
  ...navRouteDetails,
  clients: { title: 'Clients', icon: Clients },
  reports: { title: 'Reports', icon: ReportsIcon },
};

export const clientNavRouteDetails: clientNavRouteDetailsTypes = {
  ...navRouteDetails,
  upload: { title: 'Upload' },
  integrations: { title: 'Integrations' },
};

export const allNavRouteDetails:
  | adminAavRouteDetailsTypes
  | clientNavRouteDetailsTypes = {
  ...adminNavRouteDetails,
  ...clientNavRouteDetails,
};

export type navRouteDetailsType = [
  string,
  { title: string; url?: string | undefined; icon?: any },
][];

export const arrayOfAllNavRouteDetails: navRouteDetailsType = Object.entries(
  allNavRouteDetails,
);

export interface ReducerType {
  type: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  payload?: any;
}

export type extraDataTitle =
  | string
  | React.FunctionComponent
  | React.ReactElement
  | JSX.Element;

export type extraData =
  | { title: extraDataTitle; style?: CSSProperties }
  | string
  | null;

export type dataType = {
  client_name: string;
  method: string;
  date_created: string;
  batch_reference: number;
  transaction_type: string | number;
  status: extraData;
};

export const fakeData: dataType[] = [
  {
    client_name: 'Oando PLC',
    method: 'File Transfer',
    date_created: '21/10/2019',
    batch_reference: 298379868798203,
    transaction_type: 'Bulk Payment',
    status: { title: 'pending', style: { color: '#FF9595' } },
  },
  {
    client_name: 'Shell',
    method: 'REST Service',
    date_created: '21/10/2019',
    batch_reference: 298379868798203,
    transaction_type: 'Single Payment',
    status: { title: 'pending', style: { color: '#FF9595' } },
  },
  {
    client_name: 'Stanbic',
    method: 'File Transfer',
    date_created: '21/10/2019',
    batch_reference: 298379868798203,
    transaction_type: 'Single Payment',
    status: { title: 'pending', style: { color: '#FF9595' } },
  },
  {
    client_name: 'Chevron',
    method: 'SOAP Service',
    date_created: '21/10/2019',
    batch_reference: 298379868798203,
    transaction_type: 'Bulk Payment',
    status: { title: 'failed', style: { color: '#FF9595' } },
  },
  {
    client_name: 'NSE',
    method: 'REST Service',
    date_created: '21/10/2019',
    batch_reference: 298379868798203,
    transaction_type: 'Single Payment',
    status: { title: 'successful', style: { color: '#5CA594' } },
  },
];

export type batchType = {
  product_code: string;
  debit_account: number;
  amount: string;
  currency: string;
  beneficiary_code: string;
  beneficiary_name: string | number;
  narration: string;
  status: extraData;
};
export const reportData: batchType[] = [
  {
    product_code: 'SALARY PAY',
    debit_account: 1015214165,
    amount: '500,000',
    currency: 'NGN',
    beneficiary_code: 'EMP101',
    beneficiary_name: 'Micheal Uzomah',
    narration: 'September Salary Day',
    status: { title: 'successful', style: { color: '#5CA594' } },
  },
  {
    product_code: 'SALARY PAY',
    debit_account: 1015214165,
    amount: '500,000',
    currency: 'NGN',
    beneficiary_code: 'EMP101',
    beneficiary_name: 'Micheal Uzomah',
    narration: 'September Salary Day',
    status: { title: 'successful', style: { color: '#5CA594' } },
  },
  {
    product_code: 'SALARY PAY',
    debit_account: 1015214165,
    amount: '500,000',
    currency: 'NGN',
    beneficiary_code: 'EMP101',
    beneficiary_name: 'Micheal Uzomah',
    narration: 'September Salary Day',
    status: { title: 'successful', style: { color: '#5CA594' } },
  },
];
export interface AccountType {
  account_number: number;
  account_name: string;
}
export const accountData: AccountType[] = [
  {
    account_number: 298379868798203,
    account_name: 'OANDO PLC',
  },
];
export interface ContactType {
  phone: number;
  client_first_name: string;
  client_last_name: string;
  client_designation: string;
  client_account_email: string;
}
export const contactData: ContactType[] = [
  {
    phone: 2349038701275,
    client_first_name: 'Kamsi',
    client_last_name: 'George',
    client_designation: 'Corporate',
    client_account_email: 'kamsi.george@gmail.com',
  },
];
export const reduceDataForTable = (arg: any[], max?: number): any[] =>
  arg.reduce((accumulator, value) => {
    if (max) {
      const arrClone = [...Object.values(value)];
      arrClone.splice(-(arrClone.length - max), arrClone.length - max);
      accumulator.push(arrClone);
    } else {
      accumulator.push(Object.values(value));
    }

    return accumulator;
  }, []);

export interface TabItem {
  title: string;
  Component?: ReactElement | FunctionComponent<any>;
  props?: any;
}

export const tabItems: TabItem[] = [
  { title: 'Services', Component: Services },
  {
    title: 'Accounts',
    Component: Buisness,
    props: { data: accountData },
  },
  {
    title: 'Contact Persons',
    Component: Contacts,
    props: { data: contactData },
  },
  { title: 'Reports', Component: Reports },
];

export const addToLocalStorage = (key: string, value: string) => {
  localStorage.setItem(key, value);
};

const pipeFun = (f: any, g: any) => (...data: any[]) => g(f(...data));
export const pipe = (...funs: any) => funs.reduce(pipeFun);

export const configData: ConfigTypes[] = [
  { title: 'Client ID', credential: 'U-8927459234' },
  {
    title: 'Secret Key',
    credential: '0e02-3456-e342-122a-eaf0-0132-5ae3-10fa',
  },
  {
    title: 'Username',
    credential: 'Black Berry Inc',
  },
  {
    title: 'Password',
    credential: 'ee32-122a-d3f0-y',
    secret: true,
  },
];
export const shortConfigData: ConfigTypes[] = [
  {
    title: 'Secret Key',
    credential: '0e02-3456-e342-122a-eaf0-0132-5ae3-10fa',
  },
];

export const fullConfig = [configData, shortConfigData];

export type settingListInterface = {
  title: string;
  description: string;
  url: string;
  full?: boolean;
  onClick?: (arg: any) => void;
};

export const settingsList: settingListInterface[] = [
  {
    title: 'User Management',
    description: 'Users, Roles & Permissions',
    url: '/user',
  },
];

export type manageUserHeaderInterface = {
  title: string;
  subtitle: string;
  buttontext?: string;
  onButtonClick?: () => void;
};

export const managerUserHeader: manageUserHeaderInterface[] = [
  {
    title: 'Manage Users Roles',
    subtitle: 'Manage existing user roles and permissions',
    buttontext: 'Add New User Role',
  },
  {
    title: 'Manage Users',
    subtitle: 'Manage user accounts',
    buttontext: 'Add New user',
  },
];
export type manageRoleType = {
  role: string;
  permission: string;
  status: extraData;
};

export const manageData: manageRoleType[] = [
  {
    role: 'Operational Admin',
    permission: 'Create, Read, Operate, Delete',
    status: { title: 'Active', style: { color: '#5CA594' } },
  },
  {
    role: 'Operational Admin',
    permission: 'Create, Read, Operate, Delete',
    status: { title: 'Active', style: { color: '#5CA594' } },
  },
  {
    role: 'Operational Admin',
    permission: 'Create, Read, Operate, Delete',
    status: { title: 'Active', style: { color: '#5CA594' } },
  },
];

export type manageAdminType = {
  name: string;
  user_id: string;
  secretkey: string;
  role: string;
  status: extraData;
};

export const manageAdminData: manageAdminType[] = [
  {
    name: 'Jamiu Olaposi',
    user_id: 'U-8927459234',
    secretkey: '3jfffh5jh2229-vndb',
    role: 'Personnel',
    status: { title: 'Active', style: { color: '#5CA594' } },
  },
  {
    name: 'Jamiu Olaposi',
    user_id: 'U-8927459234',
    secretkey: '3jfffh5jh2229-vndb',
    role: 'Personnel',
    status: { title: 'Active', style: { color: '#5CA594' } },
  },
  {
    name: 'Jamiu Olaposi',
    user_id: 'U-8927459234',
    secretkey: '3jfffh5jh2229-vndb',
    role: 'Personnel',
    status: { title: 'Active', style: { color: '#5CA594' } },
  },
];
export const formateDate = (dateString: string) => {
  // const newDateString = dateString;
  // newDateString.split('+');
  // return newDateString[0];
  return dateString;
};

export const getStatusObject = (status: extraData): extraData => {
  if (typeof status === 'string') {
    if (status.toLowerCase() === 'pending') {
      return { title: 'Pending', style: { color: '#FFBF67' } };
    }
    if (status.toLowerCase() === 'successful') {
      return { title: 'Successful', style: { color: '#5CA594' } };
    }
    if (status.toLowerCase() === 'active') {
      return { title: 'active', style: { color: '#5CA594' } };
    }
    if (status.toLowerCase() === 'failed') {
      return { title: 'Failed', style: { color: '#FF9595' } };
    }
    if (status.toLowerCase() === 'inactive') {
      return { title: 'inactive', style: { color: '#FF9595' } };
    }
  }
  return { title: 'Pending', style: { color: '#FFBF67' } };
};

export const remove = (arr: any[], value: any): any[] => {
  return arr.filter((el: string) => el !== value);
};

export const permissionEnum: { [index: string]: string } = {
  1: 'read',
  2: 'update',
  4: 'create',
  8: 'delete',
};
const entries = Object.entries(permissionEnum);
// const values = Object.values(permissionEnum);
const keys = Object.keys(permissionEnum);
const max = Number(keys.sort()[keys.length - 1]);
export type permissionTypes = 'read' | 'update' | 'create' | string;
const permissionEnumString:
  | {
      [key in permissionTypes]: number;
    }
  | { [key: string]: number } = Object.entries(permissionEnum).reduce(
  (accumulator, currentValue: [string, permissionTypes]) => {
    const obj:
      | { [key in permissionTypes]: number }
      | { [key: string]: number } = {
      ...accumulator,
    };
    obj[currentValue[1]] = Number(currentValue[0]);
    return obj;
  },
  {},
);

export const checkClosestToNumber = (arg: number): number => {
  for (let i = 0; i < entries.length; i += 1) {
    if (Number(keys[i]) > arg) {
      return Number(keys[i - 1]);
    }
    if (arg > max) {
      return max;
    }
  }
  return arg;
};

export const getArr = (arg: number, arr: any = [], found = 0): any => {
  const closest = checkClosestToNumber(arg);
  if (closest === arg) return [permissionEnum[closest], ...arr];
  if (arg === 1) return [permissionEnum[1], ...arr];
  if (arg === 0) return [arr];

  return getArr(arg - closest, [...arr, permissionEnum[closest]]);
};

export const getPermissionStrings = (num: number) => {
  if (num === 1 || num === 2 || num === 4 || num === 8) {
    return [permissionEnum[num]];
  }
  return getArr(num);
};

export const convertToPermission = (arg: permissionTypes[]) => {
  return arg.reduce((acc: number, cur) => {
    const newAcc = acc + permissionEnumString[cur];
    return newAcc;
  }, 0);
};

export const checkPermissible = (
  requirement: number,
  value: number,
): boolean => {
  const reqPermissions = getPermissionStrings(requirement);
  const valPermissions = getPermissionStrings(value);
  if (
    reqPermissions.length > keys.length ||
    valPermissions.length > keys.length
  ) {
    throw new Error('Invalid number of permissions');
  }
  return valPermissions.every((v: string) => reqPermissions.includes(v));
};

export const checkPermission = (
  permissions: permissionTypes[],
  check: number,
): boolean => checkPermissible(check, convertToPermission(permissions));
