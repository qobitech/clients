/* eslint-disable import/no-cycle */
import * as userActions from '../actions/types';
import { addToLocalStorage } from '../utils/utility';

export type userTypes = 'client' | 'admin';
export interface UserStates {
  type: userTypes;
  token: string;
  otp: string;
  isLoggingIn: boolean;
  verified: boolean;
  id: string;
  numberOfClients: number;
  numberOfActiveClients: number;
  authorizing: boolean;
  authError: string;
  permissions: {
    client: number;
  };
}
export const initialState: UserStates = {
  type: 'admin',
  token: '',
  id: '',
  otp: '',
  isLoggingIn: false,
  numberOfClients: 0,
  numberOfActiveClients: 0,
  authError: '',
  verified: false,
  authorizing: false,
  permissions: {
    client: 2,
  },
};

export default (
  state = initialState,
  action: { type: string; payload: any; [rest: string]: any },
) => {
  switch (action.type) {
    case userActions.LOG_USER_IN_SUCCEEDED:
      addToLocalStorage('token', action.payload.token);
      addToLocalStorage('uid', action.payload.userId);
      return {
        ...state,
        token: action.payload.token,
        isLoggingIn: false,
        id: action.payload.userId,
      };
    case userActions.SET_AUTH_TOKEN:
      return { ...state, token: action.payload };
    case userActions.LOG_USER_IN_REQUESTED:
      return { ...state, isLoggingIn: true };
    case userActions.LOG_USER_IN_FAILED:
      return {
        ...state,
        isLoggingIn: false,
        authError: action.errors[0].toString(),
        username: '',
        password: '',
      };

    case userActions.LOG_OUT:
      localStorage.removeItem('uid');
      localStorage.removeItem('token');
      localStorage.removeItem('otp');
      return {
        ...initialState,
      };
    case userActions.SET_USER_ID:
      return { ...state, id: action.payload };
    case userActions.SET_NUMBER_OF_CLIENTS:
      return {
        ...state,
        numberOfClients: action.payload,
      };
    case userActions.AUTHORIZE_REQUESTED:
      return {
        ...state,
        authorizing: true,
      };
    case userActions.AUTHORIZE_FAILED:
      localStorage.removeItem('otp');
      return {
        ...state,
        authorizing: false,
        verified: false,
      };
    case userActions.AUTHORIZE_SUCCEEDED:
      addToLocalStorage('token', state.token);
      return {
        ...state,
        authorizing: false,
        verified: true,
        numberOfActiveClients: action.payload.accountsCount,
      };
    case userActions.SET_VERIFIED:
      return { ...state, verified: action.payload };
    default:
      return state;
  }
};
