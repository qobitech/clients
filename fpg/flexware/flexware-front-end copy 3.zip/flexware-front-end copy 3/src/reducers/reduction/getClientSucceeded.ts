/* eslint-disable import/no-cycle */
import { ClientsTypes, CompanyTypes } from '../interfaces';

interface CompanyClientsFromDb extends CompanyTypes {
  userId: string;
  user: {
    userId: string;
  };
}

export const getClientSuceeded = (
  state: ClientsTypes,
  action: { type: string; payload: CompanyClientsFromDb },
): ClientsTypes => {
  return {
    ...state,
    company: {
      ...state.company,
      customerName: action.payload.customerName,
      numOfservices: 1,
      status: action.payload.status ? 'active' : 'inactive',
      id: action.payload.user
        ? action.payload.user.userId
        : action.payload.userId,
      services: action.payload.services,
    },
    gettingClient: false,
  };
};
