/* eslint-disable import/no-cycle */
import { ClientsTypes, recentClientsProps } from '../interfaces';

export const addToCompanyList = (
  state: ClientsTypes,
  action: { type: string; payload: any },
): ClientsTypes => {
  return {
    ...state,
    recentClients: [
      ...action.payload.reduce((accumulator: recentClientsProps[], value: any):
        | recentClientsProps[]
        | [] => {
        accumulator.push({
          customerName: value.customerName,
          dateCreated: '21/10/2019',
          id: value.userId,

          status: value.status
            ? { title: 'Active', style: { color: 'green' } }
            : { title: 'Inactive', style: { color: 'red' } },
          numId: value.id,
        });
        return accumulator;
      }, []),
    ]
      .filter(item => item.id)
      .reverse(),
  };
};
