/* eslint-disable import/no-cycle */
import { ClientsTypes } from '../interfaces';

export const addClientSuceeded = (
  state: ClientsTypes,
  action: { type: string; payload: any },
): ClientsTypes => ({
  ...state,
  addingClient: false,
  closeModal: true,
  company: {
    ...state.company,
    customerName: action.payload.customerName,
    services: action.payload.services,
    status: action.payload.enabled ? 'active' : 'inactive',
    id: action.payload.userId,
  },
});
