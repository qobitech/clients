/* eslint-disable import/no-cycle */
import { ReportStates } from '../reports';
import { formateDate, getStatusObject } from '../../utils/utility';

export const getActiveClientSuceeded = (
  state: ReportStates,
  payload: any,
): ReportStates => {
  return {
    ...state,
    recentTransactions: payload
      .reduce((accumulator: any, currentValue: any) => {
        if (currentValue.userId) {
          accumulator.push({
            customerName:
              currentValue.customer && currentValue.customer.customerName
                ? currentValue.customer.customerName
                : 'N/A',
            transactionableType: currentValue.transactionableType,
            referenceNo: currentValue.referenceNo,
            status: getStatusObject(currentValue.status),
            date: currentValue.created_at
              ? new Date(
                  formateDate(currentValue.created_at),
                ).toLocaleDateString()
              : new Date().toLocaleDateString(),
            transactionableId: currentValue.transactionableId,
            userId: currentValue.userId || 'N/A',
            id: currentValue.id || 'N/A',
            method: currentValue.transactionableType || 'File Transfer',
            transactionDetails:
              currentValue.transactions || currentValue.transactionDetails,
            format: currentValue.fileTransfer.sftpFiles[1]
              ? currentValue.fileTransfer.sftpFiles[1].path.split('.')[1]
              : 'xml',
          });
        }
        return accumulator;
      }, [])
      .reverse(),
    requesting: false,
  };
};
