/* eslint-disable import/no-cycle */
import { combineReducers } from 'redux';
import user, { UserStates } from './user';
import app, { AppStates } from './app';
import clients from './clients';
import reports, { ReportStates } from './reports';
import { ClientsTypes } from './interfaces';

export interface ReducerTypes {
  user: UserStates;
  app: AppStates;
  clients: ClientsTypes;
  reports: ReportStates;
}
export default combineReducers({
  user,
  app,
  clients,
  reports,
});
