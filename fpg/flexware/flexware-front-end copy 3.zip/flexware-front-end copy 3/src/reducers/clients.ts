/* eslint-disable import/no-cycle */
import * as allActions from '../actions/types';
import { ClientsTypes } from './interfaces';
import { addClientSuceeded } from './reduction/addClientSucceeded';
import { getClientSuceeded } from './reduction/getClientSucceeded';
import { addToCompanyList } from './reduction/addToCompanyList';

export const initialState: ClientsTypes = {
  addingAccount: false,
  addingContact: false,
  addingClient: false,
  closeModal: false,
  fetchingClients: false,
  fetchingAccounts: false,
  fetchingContacts: false,
  gettingClient: false,
  company: {
    customerName: '',
    numOfservices: 0,
    status: 'inactive',
    id: '',
    live: false,
    services: [],
    cards: [[], []],
  },
  recentClients: [],
  contacts: [
    {
      firstName: '',
      lastName: '',
      role: '',
      email: '',
      phone: '',
    },
  ],
  accounts: [{ accountName: '', accountNumber: '' }],
};

export default (
  state = initialState,
  action: { type: string; payload: any },
): ClientsTypes => {
  switch (action.type) {
    case allActions.ADD_CLIENT_REQUESTED:
      return { ...state, addingClient: true };
    case allActions.ADD_CONTACT_REQUESTED:
      return { ...state, addingContact: true };
    case allActions.ADD_CONTACT_SUCCEEDED:
      return { ...state, addingContact: false };
    case allActions.ADD_CONTACT_FAILED:
      return { ...state, addingContact: false };
    case allActions.ADD_ACCOUNT_REQUESTED:
      return { ...state, addingAccount: true };
    case allActions.ADD_ACCOUNT_SUCCEEDED:
      return { ...state, addingAccount: false };
    case allActions.GET_CLIENT_REQUESTED:
      return { ...state, gettingClient: true };
    case allActions.GET_CLIENT_FAILED:
      return { ...state, gettingClient: false };
    case allActions.FETCH_CONTACTS_REQUESTED:
      return { ...state, fetchingContacts: true };
    case allActions.FETCH_CONTACTS_FAILED:
      return { ...state, fetchingContacts: false };
    case allActions.FETCH_ACCOUNTS_FAILED:
      return { ...state, fetchingAccounts: false };
    case allActions.FETCH_ACCOUNTS_REQUESTED:
      return { ...state, fetchingAccounts: true };
    case allActions.ADD_ACCOUNT_FAILED:
      return { ...state, addingAccount: false };
    case allActions.FETCH_CONTACTS_SUCCEEDED:
      return {
        ...state,
        contacts: [...action.payload],
        fetchingContacts: false,
      };
    case allActions.FETCH_ACCOUNTS_SUCCEEDED:
      return {
        ...state,
        accounts: [...action.payload],
        fetchingAccounts: false,
      };
    case allActions.ADD_CLIENT_SUCCEEDED:
      return addClientSuceeded(state, action);
    case allActions.ADD_CLIENT_FAILED:
      return { ...state, addingClient: false, closeModal: true };
    case allActions.CLOSE_MODAL:
      return { ...state, closeModal: false };
    case allActions.GET_CLIENT_SUCCEEDED:
      return getClientSuceeded(state, action);
    case allActions.ADD_TO_COMPANY_LIST:
      return addToCompanyList(state, action);
    case allActions.MAKE_CLIENT_LIVE:
      return { ...state, company: { ...state.company, live: true } };
    case allActions.REMOVE_LIVE_FROM_CLIENT:
      return { ...state, company: { ...state.company, live: false } };
    case allActions.UPDATE_CARD_INFORMATION:
      return {
        ...state,
        company: {
          ...state.company,
          cards: [[...action.payload[0]], [...action.payload[1]]],
        },
      };
    case allActions.LOG_OUT:
      return {
        ...state,
        ...initialState,
      };

    default:
      return state;
  }
};
