/* eslint-disable import/no-cycle */
import { extraData } from '../utils/utility';
import { serviceType } from '../components/Dashboard/admin/Clients/Services/Services';
import { appModes } from './app';
import { ConfigTypes } from '../components/elements/ConfigurationsCard/types';

export type recentClientsProps = {
  customerName: extraData;
  dateCreated: extraData;
  id: extraData;
  status: extraData;
  numId: number;
};

export interface ServiceType {
  mode: appModes;
  name: string;
  type: serviceType;
  customerId: string;
}

export interface SftpService extends ServiceType {
  createRemoteFolders: boolean;
  basePath: string;
  archive: string;
  acknowledgement: string;
}

export interface RestService extends ServiceType {
  clientId: string;
  clientSecret: string;
}

export interface SoapService extends ServiceType {
  clientId: string;
  clientSecret: string;
}

// export type eitherService = RestService | SoapService | SftpService;

export interface CompanyTypes {
  customerName: string;
  numOfservices: number;
  status: 'active' | 'inactive';
  id: string;
  live: boolean;
  services: [any, any, any] | [];
  cards: [ConfigTypes[], ConfigTypes[]];
}

export interface ClientsTypes {
  addingClient: boolean;
  addingAccount: boolean;
  addingContact: boolean;
  closeModal: boolean;
  fetchingClients: boolean;
  fetchingAccounts: boolean;
  fetchingContacts: boolean;
  gettingClient: boolean;
  recentClients: recentClientsProps[];
  company: CompanyTypes;
  contacts: {
    firstName: string;
    lastName: string;
    role: string;
    email: string;
    phone: string;
    [x: string]: any;
  }[];
  accounts: {
    accountNumber: string | number;
    accountName: string;
  }[];
}
