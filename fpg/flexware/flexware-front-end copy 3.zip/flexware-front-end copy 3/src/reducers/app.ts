import * as appActions from '../actions/types';
// eslint-disable-next-line import/no-cycle
import { ReducerType } from '../utils/utility';

export type navRoutes = 'settings' | 'dashboard' | 'documentation';
export type adminNavRoutes = navRoutes | 'clients' | 'reports';
export type clientNavRoutes = navRoutes | 'upload' | 'integrations';
export type allRoutes = adminNavRoutes | clientNavRoutes;
export type breadCrumbStackType = [] | { title: string; url: string }[];
export type appModes = 'test' | 'live';

export interface AppStates {
  currentNavSelection: adminNavRoutes | clientNavRoutes;
  breadCrumbStack: breadCrumbStackType;
  companyDisplayed: string;
  showNotification: boolean;
  notification: string;
  mode?: appModes;
  timeOutWarning: boolean;
}

const initialState: AppStates = {
  currentNavSelection: 'dashboard',
  breadCrumbStack: [],
  companyDisplayed: '',
  showNotification: false,
  notification: '',
  timeOutWarning: false,
};

export default (state = initialState, action: ReducerType): AppStates => {
  switch (action.type) {
    case appActions.SET_CURRENT_TAB:
      return {
        ...state,
        currentNavSelection: action.payload,
      };
    case appActions.UPDATE_BREAD_CRUMB_STACK:
      return {
        ...state,
        breadCrumbStack: [...action.payload],
      };
    case appActions.UPDATE_COMPANY_DISPLAYED:
      return {
        ...state,
        companyDisplayed: action.payload,
      };
    case appActions.SHOW_NOTIFICATION:
      return {
        ...state,
        showNotification: true,
        notification: action.payload,
      };
    case appActions.HIDE_NOTIFICATION:
      return {
        ...state,
        showNotification: false,
        notification: '',
      };
    case appActions.START_TIMEOUT_WARNING:
      return {
        ...state,
        timeOutWarning: true,
      };
    case appActions.STOP_TIMEOUT_WARNING:
      return {
        ...state,
        timeOutWarning: false,
      };
    case appActions.LOG_OUT:
      return {
        ...state,
        ...initialState,
      };
    default:
      return state;
  }
};
