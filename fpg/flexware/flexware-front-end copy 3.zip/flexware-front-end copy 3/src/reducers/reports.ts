/* eslint-disable import/no-cycle */
import * as userActions from '../actions/types';
import { getActiveClientSuceeded } from './reduction/getActiveClientsSucceeded';
import { batchType, extraData } from '../utils/utility';

export interface RecentTrasactionType {
  customerName: string;
  referenceNo: string;
  //   method: string;
  transactionableType: string;
  userId: string;
  id: number;
  date: string;
  transactionableId: number;
  status: extraData;
  transactionDetails: batchType[];
  format: string;
  method: string;
}

export interface ReportStates {
  recentTransactions: RecentTrasactionType[] | [];
  requesting: boolean;
}
export const initialState: ReportStates = {
  recentTransactions: [],
  requesting: false,
};

export default (
  state = initialState,
  action: { type: string; payload: any },
): ReportStates => {
  switch (action.type) {
    case userActions.GET_RECENT_CLIENTS_REQUESTED:
      return { recentTransactions: [], requesting: true };
    case userActions.GET_RECENT_CLIENTS_FAILED:
      return { ...state, requesting: false };
    case userActions.GET_RECENT_CLIENTS_SUCCEEDED:
      return getActiveClientSuceeded(state, action.payload);
    case userActions.LOG_OUT:
      return {
        ...state,
        ...initialState,
      };
    default:
      return state;
  }
};
