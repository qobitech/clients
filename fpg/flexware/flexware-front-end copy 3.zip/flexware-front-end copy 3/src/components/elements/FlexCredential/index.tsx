import React, { useState, useRef } from 'react';
import { useDispatch } from 'react-redux';
// eslint-disable-next-line import/no-cycle
import { showNotification } from '../../../actions/app';
// import CopyToClipboard from 'react-copy-to-clipboard';
import Classes from './index.module.css';
import { ReactComponent as Copy } from '../../svgs/copy.svg';
import { ConfigTypes } from '../ConfigurationsCard/types';

const FlexCredential = ({ title, credential, copy, secret }: ConfigTypes) => {
  const [, setCopied] = useState(false);
  const dispatch = useDispatch();
  const textAreaRef = useRef(null);
  function copyToClipboard(e: any, arg: string) {
    textAreaRef.current.select();
    textAreaRef.current.focus();
    document.execCommand('copy');
    e.target.focus();
    setCopied(true);
    dispatch(showNotification(`${arg} copied`));
  }
  return (
    <div className={Classes.container}>
      <div className={Classes.title}>
        <div>{title}</div>
      </div>
      <div className={Classes.credential}>
        <input
          value={`${credential}`}
          type={secret ? 'password' : 'text'}
          ref={textAreaRef}
        />
      </div>
      <div>
        <div
          className={Classes.copy}
          onClick={(e: any) => copyToClipboard(e, title)}
          onKeyPress={(e: any) => copyToClipboard(e, title)}
          tabIndex={0}
          role="button"
        >
          <Copy className={Classes.copySvg} />
          {copy || 'copy'}
        </div>
      </div>
    </div>
  );
};
export default FlexCredential;
