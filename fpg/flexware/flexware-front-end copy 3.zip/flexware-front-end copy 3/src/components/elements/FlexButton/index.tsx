/* eslint-disable react/jsx-props-no-spreading */
/* eslint-disable react/destructuring-assignment */
/* eslint-disable react/button-has-type */
import React from 'react';
import { ReactComponent as Loader } from './loader-white.svg';
import Classes from './index.module.css';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  isLoading?: boolean;
}

const FlexButton: React.FC<ButtonProps> = (props: ButtonProps) => (
  <button {...props} className={Classes.button}>
    {props.isLoading ? <Loader /> : props.children}
  </button>
);

export default FlexButton;
