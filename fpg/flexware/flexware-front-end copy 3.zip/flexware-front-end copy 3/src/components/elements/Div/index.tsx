/* eslint-disable react/jsx-props-no-spreading */
import React from 'react';

const Div: React.FC = ({ children, ...rest }) => (
  <div {...rest}>{children}</div>
);
export default Div;
