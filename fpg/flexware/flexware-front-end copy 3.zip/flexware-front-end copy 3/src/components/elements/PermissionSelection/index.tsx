import React from 'react';
import PermissionSelection from './PermissionSelection';

const PermissionSelectionContainer = ({
  toggleExpand,
}: {
  toggleExpand: any;
}) => {
  return (
    <div
      onClick={toggleExpand}
      role="button"
      tabIndex={0}
      onKeyPress={toggleExpand}
    >
      <PermissionSelection permissionNo={1} />
    </div>
  );
};

export default PermissionSelectionContainer;
