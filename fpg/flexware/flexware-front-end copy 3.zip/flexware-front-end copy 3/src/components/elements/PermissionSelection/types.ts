export interface PermissionTypeInterface {
  permissionNo: number;
}
