import React from 'react';
import ToggleButton from '../ToggleButton';
import { PermissionTypeInterface } from './types';
import { permissionEnum, checkPermissible } from '../../../utils/utility';
// import Classes from './index.module.css';

const PermissionSelection: React.FC<PermissionTypeInterface> = ({
  permissionNo,
}) => {
  return (
    <div>
      {Object.entries(permissionEnum).map((value: any) => (
        <div key={value[1]}>
          <ToggleButton
            toggled={checkPermissible(permissionNo, Number(value[0]))}
          />
        </div>
      ))}
    </div>
  );
};

export default PermissionSelection;
