/* eslint-disable react/jsx-props-no-spreading */
import React from 'react';

const Render: React.FC<{
  Component: React.ReactElement | React.FunctionComponent<any> | any;
  style?: React.CSSProperties;
}> = ({ Component, style, children, ...props }) => {
  return Component ? (
    <Component {...props} style={style}>
      {children}
    </Component>
  ) : (
    <div />
  );
};

export default Render;
