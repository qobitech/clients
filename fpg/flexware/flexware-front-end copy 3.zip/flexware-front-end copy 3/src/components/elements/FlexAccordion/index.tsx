import React from 'react';
import Classes from './index.module.css';

const FlexAccordion = ({
  onClick,
  title,
}: {
  onClick?: (arg: any) => void;
  title: string;
}) => (
  <div
    className={Classes.container}
    onClick={onClick}
    tabIndex={0}
    role="button"
    onKeyPress={onClick}
  >
    <div className={Classes.row}>
      <div className={Classes.title}>{title}</div>
      <div className={Classes.arrowHead}>
        <div className={Classes.arrow} />
      </div>
    </div>
  </div>
);

export default FlexAccordion;
