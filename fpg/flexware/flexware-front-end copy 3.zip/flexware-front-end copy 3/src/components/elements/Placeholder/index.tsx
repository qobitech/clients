import React from 'react';
import Classes from './index.module.css';

const Placeholder = ({ style }: { style?: React.CSSProperties }) => (
  <div className={Classes.container} style={style} />
);

export default Placeholder;
