import React from 'react';
import Classes from './index.module.css';
import { ReactComponent as LoaderSvg } from './svgs/loader-red.svg';

const Loader = () => (
  <div className={Classes.container}>
    <LoaderSvg />
  </div>
);

export default Loader;
