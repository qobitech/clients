import React from 'react';
import PermissionItem from './PermissionItem';

const PermissionItemContainer = () => {
  return <PermissionItem />;
};

export default PermissionItemContainer;
