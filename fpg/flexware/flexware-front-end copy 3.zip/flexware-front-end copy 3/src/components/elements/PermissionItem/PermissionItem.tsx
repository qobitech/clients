import React from 'react';
import Classes from './PermissionItem.module.css';

const PermissionItem = () => {
  return (
    <div className={Classes.box}>
      <h1>Hello</h1>
    </div>
  );
};

export default PermissionItem;
