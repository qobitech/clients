import React from 'react';
import { formTypes } from '../../Auth/types';

export declare interface FlexInputTypes
  extends React.InputHTMLAttributes<HTMLInputElement> {
  name?: formTypes;
  tip?: {
    title: string;
    url: string;
    onClick?: (arg?: any) => void;
  };
  label?: string;
  theme?: string;
  validate?: (arg?: any) => { error: boolean; message: string };
}
