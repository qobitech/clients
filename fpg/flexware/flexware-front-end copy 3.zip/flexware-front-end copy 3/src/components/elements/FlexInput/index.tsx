/* eslint-disable react/jsx-props-no-spreading */
import React from 'react';
import FlexLabel from '../FlexLabel';
import FlexTip from '../FlexTip';
import Classes from './index.module.css';
import { FlexInputTypes } from './type';

const FlexInput = (props: FlexInputTypes) => {
  const { label, tip, disabled, style, validate } = props;
  return (
    <>
      {validate &&
        (validate().error && (
          <p className={Classes.error}>{validate().message}</p>
        ))}
      {label && (
        <div className={Classes.labelTab}>
          <FlexLabel>{label}</FlexLabel>
          {tip && (
            <FlexTip
              title={tip.title}
              url={tip.url}
              onClick={tip.onClick ? tip.onClick : () => {}}
            />
          )}
        </div>
      )}
      <input
        className={Classes.input}
        {...props}
        style={
          disabled ? { ...style, backgroundColor: 'rgb(217, 217, 217)' } : style
        }
      />
    </>
  );
};
export default FlexInput;
