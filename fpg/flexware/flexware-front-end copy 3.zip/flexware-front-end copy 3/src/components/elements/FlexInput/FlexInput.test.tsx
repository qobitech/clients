/* eslint-disable */
import React, {useState,ChangeEvent} from 'react';
import Enzyme, { mount } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import FlexInput from '.';

Enzyme.configure({adapter: new Adapter()});

const Wrapper = () => {
    const [userAuthDetails, updateUserAuthDetails] = useState({});
    const setUserState = (event: ChangeEvent<HTMLInputElement>) => {
        updateUserAuthDetails({
          ...userAuthDetails,
          [event.target.name]: event.target.value,
        });
      };
    return (
    <>
        <FlexInput name="email" onChange={setUserState} value={userAuthDetails['email'] ? userAuthDetails['email'] : ''} />
    </>)
}
describe("FlexInput", () => {
    it("Renders Correctly", () => {
        mount(<FlexInput name="email" />)
    });
    it("Updates Value", () => {
        const component = mount(<Wrapper />)
        const input = component.find('input');
        input.simulate('change', {target: {name: 'email', value: 'emai'}});
        // expect(input.props().value).toBe("emai");
    })
})