/* eslint-disable react/jsx-props-no-spreading */
import React, { useState } from 'react';
import FlexTab from '../FlexTab';
import Classes from './index.module.css';
import { tabItems } from '../../../utils/utility';
import RenderComponent from '../Render';

const FlexTabs = () => {
  const [componentIndex, setComponentIndex] = useState(0);
  return (
    <div className={Classes.wrapper}>
      <div className={Classes.container}>
        {tabItems.map((item, index) => (
          <div key={item.title}>
            <FlexTab
              title={item.title}
              index={index}
              activeIndex={componentIndex}
              onClick={() => setComponentIndex(index)}
            />
          </div>
        ))}
      </div>
      <RenderComponent
        Component={tabItems[componentIndex].Component}
        {...tabItems[componentIndex].props}
      />
    </div>
  );
};

export default FlexTabs;
