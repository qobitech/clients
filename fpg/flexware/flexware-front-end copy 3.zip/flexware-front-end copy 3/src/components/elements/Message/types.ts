export interface MessageTypes {
  header?: string;
  imgUrl?: any;
  alt?: string;
  message: string;
  caption?: string;
}
