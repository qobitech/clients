import React from 'react';
import Classes from './index.module.css';
import { MessageTypes } from './types';

const Message = ({
  header,
  imgUrl: Img,
  alt,
  message,
  caption,
}: MessageTypes) => {
  return (
    <div className={Classes.container}>
      <div className={Classes.heading}>{header}</div>
      {alt && Img && (
        // <img src={imgUrl} alt={alt} className={Classes.image} />
        <Img className={Classes.image} />
      )}
      {message && <div className={Classes.message}>{message}</div>}
      {caption && <div className={Classes.placeholder}>{caption}</div>}
    </div>
  );
};

export default Message;
