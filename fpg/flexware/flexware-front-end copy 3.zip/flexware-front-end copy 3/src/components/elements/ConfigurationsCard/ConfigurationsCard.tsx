/* eslint-disable import/no-cycle */
import React from 'react';
import Classes from './index.module.css';
import Credential from '../FlexCredential';
import { ConfigTypes } from './types';

const ConfigurationCard = ({
  configData,
  live,
}: {
  configData: ConfigTypes[];
  live?: boolean;
}) => {
  return (
    <div className={Classes.container}>
      <div className={Classes.head}>
        <h2 className={Classes.heading}>002-3456577</h2>
        <div className={`${Classes.mode} ${live && Classes.live}`}>
          {live ? 'LIVE KEYS' : 'TEST'}
        </div>
      </div>
      <div className={Classes.body}>
        <div className={Classes.credentials}>
          {configData.map(value => (
            <div key={value.title}>
              <Credential
                title={value.title}
                credential={value.credential}
                secret={value.secret}
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ConfigurationCard;
