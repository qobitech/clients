/* eslint-disable import/no-cycle */
import React from 'react';
import { useSelector } from 'react-redux';
import { ReducerTypes } from '../../../reducers';
import ConfigurationCard from './ConfigurationsCard';
import { ConfigTypes } from './types';

const ConfigurationCardContainer = ({
  configData,
  live,
}: {
  configData: ConfigTypes[];
  live?: boolean;
}) => {
  const {
    clients: {
      company: { customerName },
    },
  } = useSelector((state: ReducerTypes) => state);
  // eslint-disable-next-line no-param-reassign
  configData = configData.reduce((acc: any, item: ConfigTypes, index) => {
    if (item.title === 'Username') {
      // eslint-disable-next-line no-param-reassign
      configData[index].credential = customerName;
    }
    acc.push(item);
    return acc;
  }, []);
  return <ConfigurationCard configData={configData} live={live} />;
};

export default ConfigurationCardContainer;
