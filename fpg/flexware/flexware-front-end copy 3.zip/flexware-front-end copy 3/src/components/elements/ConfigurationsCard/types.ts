export interface ConfigTypes {
  title: string;
  credential: string;
  copy?: string;
  secret?: boolean;
}
