import React from 'react';
import Classes from './index.module.css';
import { FlexTabProps } from './types';

const FlexTab = ({
  title,
  active,
  onClick,
  activeIndex,
  index,
}: FlexTabProps) => {
  let shouldBeActive = false;
  if (activeIndex === index) {
    shouldBeActive = true;
  }
  return (
    <div
      className={Classes.wrapper}
      onClick={onClick}
      tabIndex={0}
      onKeyPress={onClick}
      role="button"
    >
      <div className={Classes.container}>
        <div
          className={`${Classes.name} ${(active || shouldBeActive) &&
            Classes.active}`}
        >
          {title}
        </div>
      </div>
      <div
        className={`${Classes.div} ${(active || shouldBeActive) &&
          Classes.active}`}
      />
    </div>
  );
};

export default FlexTab;
