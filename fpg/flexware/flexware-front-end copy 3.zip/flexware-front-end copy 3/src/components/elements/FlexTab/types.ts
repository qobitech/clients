export interface FlexTabProps {
  title: string;
  active?: boolean;
  index: number;
  onClick?: (arg: any) => void;
  activeIndex: number;
}
