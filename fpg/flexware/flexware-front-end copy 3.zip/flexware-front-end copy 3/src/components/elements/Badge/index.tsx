import React from 'react';
import { ReactComponent as Edit } from '../../svgs/writing.svg';
import { ReactComponent as Delete } from '../../svgs/stop.svg';
import Classes from './index.module.css';

const Badge = ({
  style,
  edit,
  showDelete,
}: {
  style?: React.CSSProperties;
  edit?: boolean;
  showDelete?: boolean;
}) => (
  <div
    className={`${Classes.badge} ${edit && Classes.edit} ${showDelete &&
      Classes.delete}`}
    style={style}
  >
    {edit && <Edit />}
    {showDelete && <Delete />}
  </div>
);

export default Badge;
