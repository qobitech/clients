import React from 'react';
import Classes from './index.module.css';

export type BigTextType = {
  number?: number | string;
  caption?: any;
  numberProps?: string;
  align?: 'left' | 'center' | 'right';
  numberColor?: string;
  captionColor?: string;
  captionAlign?: 'left' | 'center' | 'right';
};
const BigText: React.FC<BigTextType> = ({
  number,
  numberProps,
  caption,
  align,
  captionAlign,
  numberColor,
  captionColor,
}: BigTextType) => {
  return (
    <div className={Classes.container}>
      <div
        className={`${Classes.number} ${align && Classes[align]}`}
        style={
          numberColor
            ? { color: numberColor, fontSize: numberProps }
            : { color: 'black', fontSize: numberProps }
        }
      >
        {number}
      </div>
      <p
        className={`${Classes.caption} ${captionAlign &&
          Classes[captionAlign]}`}
        style={captionColor ? { color: captionColor } : { color: 'black' }}
      >
        {caption}
      </p>
    </div>
  );
};

export default BigText;
