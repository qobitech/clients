import React, { useState } from 'react';
import IdleTimer from 'react-idle-timer';
import { useDispatch } from 'react-redux';
import { logout } from '../../../actions/app';

import ActivityTimer from '../../ActivityTimer/ActivityTimer';

const ActivityWrapper: React.FC = ({ children }) => {
  const [idleTimer, setIdleTimer] = useState(null);
  const [timeout] = useState(1000 * 1000 * 5);
  const [showModal, setShowModal] = useState(false);
  const [isTimedOut, setIsTimedOut] = useState(false);
  const dispatch = useDispatch();
  const onAction = () => {
    setIsTimedOut(false);
    if (showModal) {
      setShowModal(false);
    }
  };
  const onActive = () => {
    setIsTimedOut(false);
    if (showModal) {
      setShowModal(false);
    }
  };
  const onIdle = () => {
    setIsTimedOut(false);
    if (isTimedOut) {
      setShowModal(false);
      dispatch(logout());
    } else {
      setShowModal(true);
      idleTimer.reset();
      setIsTimedOut(true);
    }
  };
  const handleClose = () => {
    setShowModal(true);
  };
  const handleLogout = () => {
    setShowModal(false);
  };
  return (
    <>
      <IdleTimer
        ref={ref => {
          setIdleTimer(ref);
        }}
        element={document}
        onActive={onActive}
        onIdle={onIdle}
        onAction={onAction}
        timeout={timeout}
      />

      <ActivityTimer
        showModal={showModal}
        handleClose={handleClose}
        handleLogout={handleLogout}
      />

      {children}
    </>
  );
};
export default ActivityWrapper;
