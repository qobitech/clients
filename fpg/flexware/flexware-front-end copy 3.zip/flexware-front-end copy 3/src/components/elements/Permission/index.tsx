import React from 'react';
import { checkPermission, permissionTypes } from '../../../utils/utility';

const Permsission: React.FC<{
  check: number;
  permission: permissionTypes[];
}> = ({ children, permission, check }) =>
  checkPermission(permission, check) ? <>{children}</> : <></>;
export default Permsission;
