import React from 'react';
import PermissionItem from '../PermissionItem';

const PermissionItems = () => {
  return (
    <div>
      <PermissionItem />
      <PermissionItem />
    </div>
  );
};

export default PermissionItems;
