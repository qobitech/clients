import React from 'react';
import Classes from './index.module.css';

const ToggleButton: React.FC<{
  toggled?: boolean;
  onClick?: (arg?: any) => void;
}> = props => {
  const { onClick, toggled } = props;
  return (
    <div
      className={`${Classes.button} ${toggled && Classes.green}`}
      onClick={e => {
        e.stopPropagation();
        onClick && onClick(e);
      }}
      role="button"
      onKeyPress={e => {
        e.stopPropagation();
        onClick && onClick(e);
      }}
      tabIndex={0}
    >
      <div className={`${toggled && Classes.toggle}`} />
    </div>
  );
};

export default ToggleButton;
