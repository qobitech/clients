import React from 'react';
import Classes from './index.module.css';

const FlexLabel: React.FC = ({ children }) => (
  <p className={Classes.label}>{children}</p>
);

export default FlexLabel;
