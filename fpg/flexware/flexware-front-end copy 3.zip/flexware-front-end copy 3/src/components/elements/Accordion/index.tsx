/* eslint-disable react/jsx-props-no-spreading */
import React, { useRef, useState } from 'react';
import Classes from './index.module.css';

interface Accordion {
  header: { component: any; props?: any };
  body: { component: any; props?: any };
}

export const AccordionContainer: React.FC<Accordion> = ({
  header: { component: HeaderComponent, props: headerProps },
  body: { component: BodyComponent, props: bodyProps },
  ...props
}) => {
  const childComponent = useRef(null);
  const [height, setHeight] = useState(0);
  const handleClick = (extend = false, contract = false) => {
    if (extend) {
      setTimeout(() => {
        setHeight(childComponent.current.scrollHeight);
      }, 10);
      return;
    }
    if (height === 0) {
      setHeight(childComponent.current.scrollHeight);
    } else {
      setHeight(0);
    }
  };
  return (
    <div {...props}>
      <div
        className={Classes.tab}
        // onClick={
        //   height !== 0 ? () => handleClick(false, true) : () => handleClick()
        // }
        style={{
          boxShadow: `${
            height !== 0 ? '0 2px 5px rgba(0, 0, 0, 0.1)' : 'none'
          }`,
        }}
        role="button"
        tabIndex={0}
        // onKeyPress={
        //   height !== 0 ? () => handleClick(false, true) : () => handleClick()
        // }
      >
        {/* <div className={Classes.header}>
          <div>{header}</div>
        </div> */}
        <HeaderComponent
          {...headerProps}
          toggleExpand={
            height !== 0 ? () => handleClick(false, true) : () => handleClick()
          }
        />
        {/* <Arrow
          className={Classes.arrow}
          style={{ transform: `rotate(${height !== 0 ? 180 : height}deg)` }}
        /> */}
      </div>
      <div
        style={{ height: `${height}px` }}
        ref={childComponent}
        className={Classes.children}
      >
        <BodyComponent {...bodyProps} updateHeight={() => handleClick(true)} />
        {/* {children
          ? cloneElement(children as React.ReactElement<any>, {
              updateHeight: () => handleClick(true),
            })
          : ''} */}
      </div>
    </div>
  );
};

export default AccordionContainer;
