import React from 'react';
import Accrodion from '../Accordion';
import PermissionSelection from '../PermissionSelection';
import PermissionItems from '../PermissionItems';

const PermissionSelector = () => {
  return (
    <div>
      <Accrodion
        header={{ component: PermissionSelection }}
        body={{ component: PermissionItems }}
      />
    </div>
  );
};
export default PermissionSelector;
