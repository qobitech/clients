import React from 'react';
import PermissionSelector from './PermissionSelector';

const PermissionSelectorContainer = () => {
  return (
    <div>
      <PermissionSelector />
    </div>
  );
};
export default PermissionSelectorContainer;
