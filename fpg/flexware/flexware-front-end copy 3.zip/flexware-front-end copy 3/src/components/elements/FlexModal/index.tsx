import React, { useEffect } from 'react';
import Classes from './index.module.css';

interface FlexModalTypes {
  type?: 'landscape' | 'portrait';
  cleanUp?: any;
  fit?: boolean;
  style?: React.CSSProperties;
}

const FlexModal: React.FC<FlexModalTypes> = ({
  children,
  type,
  cleanUp,
  fit,
  style,
}) => {
  useEffect(() => {
    return () => {
      cleanUp && cleanUp();
    };
  }, [cleanUp]);
  return (
    <div className={Classes.container}>
      <div
        className={`${Classes.modal} ${type === 'landscape' &&
          Classes.landscape} ${fit && Classes.fit}`}
        style={style}
      >
        {children}
      </div>
    </div>
  );
};

export default FlexModal;
