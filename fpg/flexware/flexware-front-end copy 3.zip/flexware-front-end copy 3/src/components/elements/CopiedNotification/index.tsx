import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { hideNotification } from '../../../actions/app';
import { ReducerTypes } from '../../../reducers';
import Styles from './index.module.css';

const CopiedNotification = () => {
  const dispatch = useDispatch();
  const {
    app: { notification, showNotification },
  } = useSelector((state: ReducerTypes) => state);
  useEffect(() => {
    if (showNotification) {
      setTimeout(() => {
        dispatch(hideNotification());
      }, 5000);
    }
  }, [showNotification, dispatch]);

  return (
    <div className={`${Styles.container} ${!showNotification && Styles.hide}`}>
      <div>{notification}</div>
      <div
        className={Styles.close}
        onClick={() => dispatch(hideNotification())}
        tabIndex={0}
        role="button"
        onKeyPress={() => dispatch(hideNotification())}
      >
        x
      </div>
    </div>
  );
};

export default CopiedNotification;
