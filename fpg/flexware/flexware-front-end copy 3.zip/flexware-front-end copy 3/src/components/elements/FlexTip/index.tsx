import React from 'react';
import PropTypes from 'prop-types';
import Classes from './index.module.css';

const FlexTip: React.FC<{
  title: string;
  url: string;
  onClick?: () => void;
}> = ({ title, url, onClick }) => (
  <a href={url} className={Classes.tip} onClick={onClick}>
    {title}
  </a>
);

FlexTip.propTypes = {
  url: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
};
export default FlexTip;
