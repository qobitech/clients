/* eslint-disable import/no-cycle */
import React from 'react';
import { extraDataTitle } from '../../../utils/utility';
import Render from '../Render';

const Td = ({ itemData }: { itemData: any; key?: any }) => {
  let innnerElement: extraDataTitle;
  let style: React.CSSProperties;
  if (typeof itemData === 'string' || typeof itemData === 'number') {
    style = {};
    innnerElement = itemData.toString();
  } else {
    if (itemData === null) {
      innnerElement = <Render Component={<div />} />;
    }
    style = itemData.style;
    if (typeof itemData === 'function') {
      innnerElement = <Render Component={itemData} />;
    } else {
      innnerElement = itemData.title;
    }
  }
  return (
    <td style={style} key={Math.random()}>
      {innnerElement}
    </td>
  );
};

export default Td;
