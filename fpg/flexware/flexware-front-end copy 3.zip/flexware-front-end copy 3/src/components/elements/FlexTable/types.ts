import React from 'react';

export interface FlextableType {
  headers: any[];
  data?: any[];
  title?: string;
  onRowClick?: (index: any, rest?: any[]) => void;
  style?: React.CSSProperties;
  rowEditable?: boolean;
  removeEmpty?: boolean;
}
