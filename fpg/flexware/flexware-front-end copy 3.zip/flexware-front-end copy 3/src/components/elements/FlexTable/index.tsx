/* eslint-disable import/no-cycle */
import React from 'react';
import Classes from './index.module.css';
import { FlextableType } from './types';
import { extraData, remove } from '../../../utils/utility';
import Td from './Td';
import Badge from '../Badge';

const FlexTable = ({
  headers,
  data,
  title,
  onRowClick,
  style,
  rowEditable,
}: // removeEmpty,
FlextableType) => {
  let tableHeaders = headers;
  const setTableHeaders = (newHeaders: any) => {
    tableHeaders = newHeaders;
  };
  return (
    <div className={Classes.tableContainer} style={style}>
      <div className={Classes.tableHeader}>{title ? <p>{title}</p> : null}</div>
      <table className={Classes.table}>
        <thead>
          <tr>
            {tableHeaders.map(h => (
              <th key={h}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data &&
            data.map((item, index) => (
              <tr
                key={Math.random()}
                onClick={onRowClick ? () => onRowClick(index) : () => ''}
              >
                {item.map(
                  (
                    itemData: string | number | extraData,
                    itemIndex: number,
                  ) => {
                    !itemData &&
                      setTableHeaders(
                        remove(tableHeaders, tableHeaders[itemIndex]),
                      );
                    // console.log(tableHeaders);
                    return itemData ? (
                      <Td itemData={itemData} key={Math.random()} />
                    ) : null;
                  },
                )}
                <td
                  style={
                    rowEditable
                      ? {
                          display: 'flex',
                          width: rowEditable ? '100px' : 'fi',
                          justifyContent: 'space-between',
                        }
                      : {}
                  }
                >
                  {rowEditable && (
                    <>
                      <Badge edit />
                      <Badge showDelete />
                    </>
                  )}
                </td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
};

export default FlexTable;
