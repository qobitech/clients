type Forwards = {
  title: string;
  src: string;
};

export declare interface FlexCardProps {
  title: string;
  children: string;
  forward?: Forwards;
}
