/* eslint-disable react/jsx-props-no-spreading */
import React from 'react';
import FlexCard from './FlexCard';
import { FlexCardProps } from './types';

const FlexCardContainer = (props: FlexCardProps) => {
  return <FlexCard {...props} />;
};

export default FlexCardContainer;
