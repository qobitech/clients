import React from 'react';
import { Link } from 'react-router-dom';
import Classes from './FlexCard.module.css';
import { FlexCardProps } from './types';

const FlexCard = ({ title, children, forward }: FlexCardProps) => {
  return (
    <div className={Classes.container}>
      <div className={Classes.dismiss}>
        <div>dismiss</div>
      </div>
      <div className={Classes.titleSpan}>
        <div className={Classes.progress} />
        <div className={Classes.title}>{title}</div>
      </div>
      <div className={Classes.content}>{children}</div>
      {forward && forward.title && (
        <div className={Classes.forward}>
          <Link to={forward.src}>{forward.title}</Link>
        </div>
      )}
    </div>
  );
};

export default FlexCard;
