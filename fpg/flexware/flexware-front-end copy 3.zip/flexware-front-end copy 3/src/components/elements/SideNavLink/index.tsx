import React from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { ReducerTypes } from '../../../reducers';
import Classes from './index.module.css';

type SideNavlinkTypes = {
  to: string;
  active?: boolean;
  name: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  onClick: (arg: any) => void;
  icon?: any;
};

const SideNavLink: React.FC<SideNavlinkTypes> = ({
  to,
  children,
  active,
  name,
  onClick,
  icon: Icon,
}) => {
  const {
    app: { currentNavSelection },
  } = useSelector((state: ReducerTypes) => state);
  return (
    <div
      className={Classes.container}
      onClick={onClick}
      tabIndex={0}
      role="button"
      onKeyPress={onClick}
    >
      <Link
        to={to}
        className={`${
          active ? Classes.active : undefined
        } ${currentNavSelection === name && Classes.active}`}
      >
        {Icon ? <Icon /> : <div className={Classes.imgPlaceholder} />}

        <div className={Classes.textDiv}>{children}</div>
      </Link>
    </div>
  );
};

export default SideNavLink;
