import React from 'react';

export declare type formTypes =
  | 'email'
  | 'username'
  | 'customerName'
  | 'phone'
  | 'password'
  | 'search'
  | 'accountName'
  | 'accountNumber'
  | 'firstName'
  | 'lastName'
  | 'designation'
  | 'role'
  | 'ubaCorporateId'
  | 'ubaUserId'
  | 'otp';
export declare type AuthUserDetailsTypes = {
  [key in formTypes]: string;
};

export declare interface AuthPropTypes {
  onChange?: ((event: React.ChangeEvent<HTMLInputElement>) => void) | undefined;
  values:
    | {
        [key in formTypes]: string;
      }
    | { [key: string]: string };
  signup: boolean;
  isLoggingIn: boolean;
  verifying: boolean;
  tokenSet: boolean;
  uid: string;
  token: string;
  showExtraFields: boolean;
  getOtp: () => void;
  userType: string;
  error: string;
}
