/* eslint-disable import/no-cycle */
import React, { useState, ChangeEvent, useEffect } from 'react';
import { Redirect } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { setAuthToken, setUid } from '../../actions/user';
import { setWarningState } from '../../actions/app';
import { ReducerTypes } from '../../reducers';
import { AuthUserDetailsTypes } from './types';
import Auth from './Auth';
import api from '../../utils/api';

type AuthContainerProps = {
  signup: boolean;
};

const AuthContainer = ({ signup }: AuthContainerProps) => {
  const dispatch = useDispatch();
  const {
    user: { isLoggingIn, token, id, authorizing, verified, type, authError },
  } = useSelector((state: ReducerTypes) => state);
  const [userAuthDetails, updateUserAuthDetails] = useState<
    AuthUserDetailsTypes | {}
  >({});
  const setUserState = (event: ChangeEvent<HTMLInputElement>) => {
    updateUserAuthDetails({
      ...userAuthDetails,
      [event.target.name]: event.target.value,
    });
  };

  // const getNewToken = () => {
  //   fetch
  // }

  const getOtp = () => {
    let idToReq = id;
    if (!id) {
      const usrId = localStorage.getItem('uid');

      if (usrId) {
        idToReq = usrId;
        dispatch(setUid(usrId));
      }
    }
    api
      .post('/otp/resend', { userId: idToReq }, token)
      .then(data => {
        if (!data.error) {
          localStorage.setItem('otp', data.otpValue);
        }
      })
      .catch(err => {
        console.log(err);
      });
  };

  useEffect(() => {
    const authToken = localStorage.getItem('token');
    if (authToken) {
      dispatch(setWarningState(false));
      dispatch(setAuthToken(authToken));
    }
  }, [dispatch, authError]);

  return verified ? (
    <Redirect to="/admin/dashboard" />
  ) : (
    <Auth
      onChange={setUserState}
      values={userAuthDetails}
      signup={signup}
      isLoggingIn={isLoggingIn}
      verifying={authorizing}
      tokenSet={!!token}
      token={token}
      uid={id}
      showExtraFields={!!token}
      getOtp={getOtp}
      userType={type}
      error={authError}
    />
  );
};

export default AuthContainer;
