/* eslint-disable no-nested-ternary */
import React, { useRef, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useDispatch } from 'react-redux';
// eslint-disable-next-line import/no-cycle
// import ActivityTimer from '../ActivityTimer';
import { AuthPropTypes } from './types';
import Classes from './Auth.module.css';
import FlexInput from '../elements/FlexInput';
import FlexButton from '../elements/FlexButton';
import { logUserIn, authorize } from '../../actions/user';
import { logout } from '../../actions/app';

const Auth: React.FC<AuthPropTypes> = ({
  onChange,
  values,
  signup,
  isLoggingIn,
  tokenSet,
  verifying,
  uid,
  token,
  showExtraFields,
  getOtp,
  userType,
  error,
}: AuthPropTypes) => {
  const dispatch = useDispatch();
  const errMessage = useRef(null);
  const [height, setHeight] = useState(0);
  useEffect(() => {
    if (error) {
      if (errMessage && errMessage.current) {
        setTimeout(() => {
          setHeight(errMessage.current.scrollHeight);
        }, 10);
      }
    }
  });
  return (
    <div
      className={Classes.container}
      style={{
        backgroundImage: `url(${process.env.PUBLIC_URL}/images/background.jpg)`,
      }}
    >
      <div className={Classes.header}>
        <div className={Classes.title}>
          <h1>Host2Host</h1>
          <h4>Client & Administrative Portal</h4>
        </div>
        <img src={`${process.env.PUBLIC_URL}/images/logo.svg`} alt="logo" />
      </div>
      {/* <ActivityTimer /> */}
      <div className={Classes.left}>
        <div>
          <h1>Let’s automate your process</h1>
          <h3>Host2Host is a middleware platform that b…</h3>
        </div>
      </div>
      <form className={Classes.form}>
        <div className={Classes.innerContainer}>
          <div className={Classes.instructions}>
            <h3>Welcome back!</h3>
            <p>Please login to your account</p>
          </div>
          <div className={Classes.error} style={{ height }} ref={errMessage}>
            {error}
          </div>
          <div className={Classes.inputBox}>
            {!showExtraFields && (
              <FlexInput
                type="text"
                name="username"
                onChange={onChange}
                value={values.username ? values.username : ''}
                label="Email Address"
                placeholder="Enter Email"
                disabled={showExtraFields}
                // validate={() => ({
                //   error: values.username && values.username.length < 5,
                //   message: 'Username Should be more than 5 characters',
                // })}
              />
            )}
          </div>
          {signup && (
            <div className={Classes.inputBox}>
              <FlexInput
                type="text"
                name="customerName"
                onChange={onChange}
                value={values.customerName ? values.customerName : ''}
                label="Customer Name"
                placeholder="Oando PLC"
              />
            </div>
          )}
          {signup && (
            <div className={Classes.inputBox}>
              <FlexInput
                type="number"
                name="phone"
                onChange={onChange}
                value={values.phone ? values.phone : ''}
                label="Phone Number"
                placeholder="E.g 08149583224"
              />
            </div>
          )}
          {!signup && !showExtraFields && (
            <div className={Classes.inputBox}>
              <FlexInput
                type="password"
                name="password"
                onChange={onChange}
                value={values.password ? values.password : ''}
                label="Enter Password"
                placeholder="Enter Password"
                disabled={showExtraFields}
                // tip={{ title: 'Need help?', url: '/help' }}
              />
            </div>
          )}
          {!signup && showExtraFields && (
            <div className={Classes.inputBox}>
              <FlexInput
                type="number"
                name="otp"
                onChange={onChange}
                value={values.otp ? values.otp : ''}
                label="Enter OTP"
                placeholder="Enter OTP"
                tip={{
                  title: 'Resend OTP?',
                  url: '',
                  onClick: e => {
                    e.preventDefault();
                    getOtp();
                  },
                }}
                required
              />
            </div>
          )}
          <div className={Classes.buttonContainer}>
            <div className={Classes.flexedContainer}>
              <FlexButton
                type="submit"
                onClick={e => {
                  e.preventDefault();
                  tokenSet
                    ? dispatch(
                        authorize(
                          { otp: values.otp || '', userId: uid },
                          token,
                        ),
                      )
                    : dispatch(logUserIn({ ...values, usertype: userType }));
                }}
                isLoading={isLoggingIn || verifying}
              >
                {signup ? 'Create User Account' : 'Sign In'}
              </FlexButton>
              {!signup && showExtraFields && (
                <FlexButton
                  onClick={e => {
                    e.preventDefault();
                    dispatch(logout());
                  }}
                >
                  Cancel
                </FlexButton>
              )}
            </div>
            <Link
              to={signup ? '/signin' : '/signup'}
              className={Classes.link}
            />
          </div>
        </div>
      </form>
    </div>
  );
};
export default Auth;
