import React, { Suspense, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
// import ActivityTimer from '../ActivityTimer';
import CopiedNotification from '../elements/CopiedNotification';
import { updateComapnyDisplayed } from '../../actions/app';
import { ReducerTypes } from '../../reducers';
import Classes from './Dashboard.module.css';
import SideNav from './SideNav/SidenavContainer';
import { DashboardTypes } from './types';
import AdminRoutes from './AdminRoutes';
import Loader from '../elements/Loader';

const Dashboard = ({
  navOpen,
  toggleNav,
  type,
  match,
  breadCrumbStack,
  updateBreadCrumbByIndex,
}: DashboardTypes) => {
  const {
    app: { companyDisplayed },
  } = useSelector((state: ReducerTypes) => state);
  const location = useLocation();
  const dispatch = useDispatch();
  const path = location.pathname.split('/')[3]
    ? location.pathname.split('/')[3]
    : 'dashboard';
  useEffect(() => {
    dispatch(updateComapnyDisplayed(path));
  }, [path, dispatch]);
  // {filteredArr[0][1].title}
  return (
    <div className={Classes.container}>
      <SideNav navOpen={navOpen} toggleNav={toggleNav} />
      {/* <ActivityTimer /> */}
      <div className={Classes.rightSide}>
        <div className={Classes.bezzel}>
          <CopiedNotification />
          <div
            className={Classes.hamburger}
            onClick={() => toggleNav(!navOpen)}
            onKeyPress={() => toggleNav(!navOpen)}
            role="button"
            tabIndex={0}
          >
            <div />
            <div />
            <div />
          </div>
          <div className={Classes.link}>
            {breadCrumbStack &&
              breadCrumbStack.map(
                (el: { title: string; url: string }, index: number) => (
                  <Link
                    to={el.url}
                    onClick={() => updateBreadCrumbByIndex(index)}
                  >
                    {`${el.title} >`}
                  </Link>
                ),
              )}
          </div>
          <div className={Classes.breadcrumb}>{companyDisplayed}</div>
        </div>
        {type === 'admin' && (
          <Suspense
            fallback={
              // eslint-disable-next-line react/jsx-wrap-multilines
              <Loader />
            }
          >
            <AdminRoutes match={match} />
          </Suspense>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
