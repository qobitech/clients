import { ChangeEvent } from 'react';
import { formTypes } from '../../../../Auth/types';

export interface AccountsProps {
  path?: string;
  toggleModal: (arg: boolean) => void;
  showModal: boolean;
  setUserState?: (event: ChangeEvent<HTMLInputElement>) => void;
  userAuthDetails: { [key in formTypes]: string };
  handleSubmit: (arg: any) => void;
  cleanUp?: () => void;
  addingClient?: boolean;
  accounts: any[];
  addingAccount: boolean;
  fetchingAccounts: boolean;
  accountVerified: boolean;
  verifyAccount: (arg?: any) => void;
  verifyingAccount: boolean;
}
