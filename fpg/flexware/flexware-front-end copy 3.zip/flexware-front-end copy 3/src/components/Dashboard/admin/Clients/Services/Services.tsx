/* eslint-disable import/no-cycle */
import React from 'react';
import Classes from './Services.module.css';
import ToggleButton from '../../../../elements/ToggleButton';
import ConfigurationsCard from '../../../../elements/ConfigurationsCard/ConfigurationsCardContainer';
// import { fullConfig } from '../../../../../utils/utility';

export type serviceType = 'sftp' | 'soap' | 'rest';

const Services = ({
  live,
  toggleLiveClient,
  type,
  fullConfig,
}: {
  live: boolean;
  toggleLiveClient: (arg?: boolean) => void;
  type?: serviceType;
  fullConfig: [any[], any[]];
}) => {
  return (
    <div>
      <div className={Classes.top}>
        <div>
          <h2>Activation Status</h2>
          {type !== 'sftp' ? (
            <p>
              Set the status for your integration from “Test” to “Live” mode
            </p>
          ) : (
            <p>Use the ‘Server’ and ‘Client’ configurations to setup</p>
          )}
        </div>
        {type !== 'sftp' && (
          <div className={Classes.toggle}>
            <div className={Classes.caption}>TEST</div>
            <div className={Classes.tButton}>
              <ToggleButton
                toggled={live}
                onClick={() => {
                  toggleLiveClient(!live);
                }}
              />
            </div>
            <div className={Classes.caption}>LIVE</div>
          </div>
        )}
      </div>
      <div
        className={`${Classes.bottom} ${live && Classes.reveal} ${type ===
          'sftp' && Classes.alt}`}
      >
        <ConfigurationsCard configData={fullConfig[0]} live />
        <ConfigurationsCard configData={fullConfig[1]} />
      </div>
    </div>
  );
};

export default Services;
