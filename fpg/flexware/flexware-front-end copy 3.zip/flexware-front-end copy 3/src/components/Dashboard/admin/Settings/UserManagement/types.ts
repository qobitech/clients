import { settingListInterface } from '../../../../../utils/utility';

interface UserManagementProps extends settingListInterface {
  sth?: any;
}
