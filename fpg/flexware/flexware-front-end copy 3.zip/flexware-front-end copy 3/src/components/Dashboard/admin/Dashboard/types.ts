import { userTypes } from '../../../../reducers/user';

export interface DashBoardTypes {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  history: any;
  type: userTypes;
  activeClients: number;
  inactiveClients: number;
}
