/* eslint-disable import/no-cycle */
import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Switch, Route, useHistory } from 'react-router-dom';
import { ReducerTypes } from '../../../../reducers';
import Reports from './Reports';
import Report from './Report/ReportContainer';
import { dataType } from '../../../../utils/utility';
import { getRecentTransactions } from '../../../../actions/reports';

type ReportsProps = {
  data: dataType[];
};

const ReportsContainer: React.FC<ReportsProps> = props => {
  const history = useHistory();
  const dispatch = useDispatch();
  const { pathname } = history.location;
  const [defaultPath] = useState(pathname);
  const changeUrl = (arg: number) => {
    history.push(`${defaultPath}/report/${arg}`);
  };
  const {
    user: { token },
    reports: { recentTransactions, requesting },
  } = useSelector((state: ReducerTypes) => state);
  useEffect(() => {
    dispatch(getRecentTransactions(token));
  }, [dispatch, token]);

  return (
    <div>
      <Switch>
        <Route
          path={`${defaultPath}/report/:id`}
          exact
          render={() => <Report />}
        />
        <Route
          path={`${defaultPath}/`}
          exact
          render={() => (
            <Reports
              data={recentTransactions}
              onRowClick={changeUrl}
              loading={requesting}
            />
          )}
        />
      </Switch>
    </div>
  );
};

export default ReportsContainer;
