import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import {
  updateBreadCrumbStack,
  updateComapnyDisplayed,
} from '../../../../../actions/app';
import ManageUsers from './ManageUsers';
import { manageData } from '../../../../../utils/utility';

const ManageUsersContainer = ({ changeUrl }: { changeUrl: () => void }) => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(updateComapnyDisplayed('Manage Users'));
    dispatch(
      updateBreadCrumbStack([
        { title: 'Settings', url: '/admin/dashboard/settings' },
        { title: 'User Management', url: '/admin/dashboard/settings/user' },
      ]),
    );
  }, [dispatch]);
  useEffect(() => {
    return () => {
      dispatch(updateComapnyDisplayed(''));
      dispatch(updateBreadCrumbStack([]));
    };
  }, [dispatch]);
  return <ManageUsers data={manageData} onButtonClick={changeUrl} />;
};

export default ManageUsersContainer;
