import React from 'react';
import ManageUserHeader from '../ManageUsers/ManageUserHeader';
import FlexInput from '../../../../elements/FlexInput';
import FlexButton from '../../../../elements/FlexButton';
import Classes from './index.module.css';

const AddUser = () => {
  return (
    <div className={Classes.wrapper}>
      <div className={Classes.container}>
        <div className={Classes.header}>
          <ManageUserHeader
            title="Add new user"
            subtitle="set up a new admin contact"
          />
        </div>
        <div className={Classes.divContain}>
          <div className={Classes.rowContain}>
            <p className={Classes.text}>Enter account details</p>
            <FlexInput
              type="text"
              name="firstName"
              label="First Name"
              placeholder="placehold text"
              style={{ marginBottom: '20px' }}
            />

            <FlexInput
              type="text"
              name="lastName"
              label="Last Name"
              placeholder="placehold text"
              style={{ marginBottom: '20px' }}
            />

            <FlexInput
              type="email"
              name="email"
              label="Email Address"
              placeholder="placehold text"
              style={{ marginBottom: '20px' }}
            />

            <FlexInput
              type="password"
              name="password"
              label="Password"
              placeholder="placehold text"
              style={{ marginBottom: '20px' }}
            />
            <p className={Classes.text}>Assign Role</p>
            <div className={Classes.selectContain}>
              <div className={Classes.selectdiv}>
                <select>
                  <option selected>Operations</option>
                  <option>Marketting</option>
                  <option>Cash Manager</option>
                  <option>Sales</option>
                </select>
              </div>
            </div>
            <FlexButton
              style={{
                backgroundColor: 'black',
                color: 'white',
                width: '75%',
                marginTop: '50px',
              }}
            >
              Add New User
            </FlexButton>
          </div>
        </div>
      </div>
    </div>
  );
};
export default AddUser;
