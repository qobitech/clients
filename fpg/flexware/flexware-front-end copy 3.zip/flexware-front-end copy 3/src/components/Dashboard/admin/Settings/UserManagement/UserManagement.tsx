import React from 'react';
import Classes from './index.module.css';
import Setting from '../Setting';
import FlexAccordion from '../../../../elements/FlexAccordion';
import { settingsList } from '../../../../../utils/utility';

const UserManagement = ({
  changeUrl,
}: {
  changeUrl: (arg: string) => void;
}) => {
  const [setting] = settingsList;
  return (
    <div className={Classes.container}>
      <Setting
        title={setting.title}
        description={setting.description}
        url={setting.url}
        full
      />
      <div className={Classes.second}>
        <FlexAccordion
          title="Manage user roles and permissions"
          onClick={() => changeUrl('/user/manageusers')}
        />
      </div>
      <FlexAccordion
        title="Manage admin user accounts on the platform"
        onClick={() => changeUrl('/user/manageadmins')}
      />
    </div>
  );
};
export default UserManagement;
