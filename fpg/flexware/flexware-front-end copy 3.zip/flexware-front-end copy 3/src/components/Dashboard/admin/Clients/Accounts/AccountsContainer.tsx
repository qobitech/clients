/* eslint-disable import/no-cycle */
import React, { useState, ChangeEvent, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Accounts from './Accounts';
import api from '../../../../../utils/api';
import { ReducerTypes } from '../../../../../reducers';
import * as types from '../../../../../actions/types';
import { reduceDataForTable } from '../../../../../utils/utility';

const AccountsContainer = ({ path }: { path: string }) => {
  const dispatch = useDispatch();
  const {
    clients: {
      addingClient,
      company: { id },
      accounts,
      fetchingAccounts,
    },
    user: { token },
  } = useSelector((state: ReducerTypes) => state);

  const [showModal, toggleModal] = useState(false);
  const [addingAccount, togleAddingAccount] = useState(false);
  const [accountVerified, verifyAccount] = useState(false);
  const [verifyingAccount, setVerifyingAccount] = useState(false);

  // accounts/inquire

  // accountNo

  // const cleanUp = () => {
  //   dispatch(
  //     updateBreadCrumbStack([
  //       ...breadCrumbStack,
  //       { title: 'clients', url: path },
  //     ]),
  //   );
  //   history.push(`${path}/company`);
  // };

  const [userAuthDetails, updateUserAuthDetails] = useState<any>({});

  const setUserState = (event: ChangeEvent<HTMLInputElement>) => {
    updateUserAuthDetails({
      ...userAuthDetails,
      [event.target.name]: event.target.value,
    });
  };

  const accountsFortable: any[] = reduceDataForTable(
    accounts.reduce((accumulator: any[], value) => {
      const obj: any = {};
      obj.accountNumber = value.accountNumber;
      obj.accountName = value.accountName;
      accumulator.push(obj);
      return accumulator;
    }, []),
  );

  useEffect(() => {
    dispatch({ type: types.FETCH_ACCOUNTS_REQUESTED });
    api
      .get(`/accounts/${id}`, token)
      .then(data => {
        dispatch({ type: types.FETCH_ACCOUNTS_SUCCEEDED, payload: data });
      })
      .catch(err => {
        dispatch({ type: types.FETCH_ACCOUNTS_FAILED });
        console.log(err);
      });
  }, [id, token, dispatch]);

  const handleAddClient = (arg: any) => {
    togleAddingAccount(true);
    api
      .post('/accounts', { ...userAuthDetails, userId: id }, token)
      .then(data => {
        dispatch({
          type: types.FETCH_ACCOUNTS_SUCCEEDED,
          payload: [...accounts, userAuthDetails],
        });
        verifyAccount(false);
        togleAddingAccount(false);
        toggleModal(!showModal);
      })
      .catch(() => {
        verifyAccount(false);
        toggleModal(!showModal);
      });
  };

  const handleVerify = () => {
    setVerifyingAccount(true);
    api
      .post(
        '/accounts/inquire',
        { accountNumber: userAuthDetails.accountNumber },
        token,
      )
      .then(res => {
        if (!res.error) {
          setVerifyingAccount(false);
          verifyAccount(true);
          updateUserAuthDetails({
            ...userAuthDetails,
            accountName: res.customerName,
            email: res.email,
            phone: res.phone,
          });
        }
        setVerifyingAccount(false);
      })
      .catch(() => {
        setVerifyingAccount(false);
      });
  };

  return (
    <Accounts
      path={path}
      showModal={showModal}
      toggleModal={toggleModal}
      setUserState={setUserState}
      userAuthDetails={userAuthDetails}
      handleSubmit={handleAddClient}
      addingClient={addingClient}
      accounts={accountsFortable}
      addingAccount={addingAccount}
      fetchingAccounts={fetchingAccounts}
      verifyAccount={handleVerify}
      accountVerified={accountVerified}
      verifyingAccount={verifyingAccount}
    />
  );
};

export default AccountsContainer;
