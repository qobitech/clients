import React from 'react';
import Classes from './index.module.css';
import Bigtext from '../../../elements/BigText';
// import PermissionSelector from '../../../elements/PermissionSelector';
import FlexButton from '../../../elements/FlexButton';
import { DashBoardTypes } from './types';
import { ReactComponent as Woman } from './woman.svg';

const Dashboard = ({ history, type, activeClients }: DashBoardTypes) => {
  return (
    <div className={Classes.container}>
      <div className={Classes.topRow}>
        <div className={Classes.greetingBox}>
          <h2>Welcome back!</h2>
          <h4>Lorem ipsum dolor sit amet, consetetur.</h4>
        </div>
        <Woman className={Classes.woman} />
      </div>

      <div className={Classes.notifRow}>
        <div className={Classes.first}>
          <Bigtext
            caption="Payment Requests"
            captionColor="#222222"
            number="0"
            numberColor="#222222"
            numberProps="5em"
          />
          <div className={Classes.button}>
            <FlexButton
              // style={{ backgroundColor: '#FF99AA' }}
              onClick={() => history.push(`/${type}/dashboard/reports`)}
            >
              View Reports
            </FlexButton>
          </div>
        </div>
        <div className={Classes.second}>
          <Bigtext
            caption="Active Clients"
            captionColor="#222222"
            number={activeClients.toString()}
            numberColor="#222222"
            numberProps="5em"
          />
          <div className={Classes.button}>
            {/* <FlexButton
              // style={{ backgroundColor: '#8FB1D9' }}
              onClick={() => history.push(`/${type}/dashboard/clients`)}
            >
              Manage Clients
            </FlexButton> */}
            <FlexButton
              // style={{ backgroundColor: '#8FB1D9' }}
              onClick={() => history.push(`/${type}/dashboard/clients`)}
            >
              Manage Clients
            </FlexButton>
          </div>
        </div>
      </div>
      {/* <PermissionSelector /> */}
    </div>
  );
};

export default Dashboard;
