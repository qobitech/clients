/* eslint-disable import/no-cycle */
import React from 'react';
import Badge from '../../../../elements/Badge';
import Classes from './index.module.css';
import { settingListInterface } from '../../../../../utils/utility';

const Settings = ({
  title,
  description,
  onClick,
  full,
}: settingListInterface) => {
  return (
    <div
      className={Classes.container}
      onClick={onClick}
      onKeyPress={onClick}
      tabIndex={0}
      role="button"
    >
      <div className={Classes.containRow}>
        <div className={`${Classes.first} ${full && Classes.full}`}>
          <div className={Classes.flexBadge}>
            <div className={Classes.badge}>
              <Badge
                style={{
                  backgroundColor: '#F0F0F0',
                  height: '30px',
                  width: '30px',
                  borderRadius: '8px',
                }}
              />
            </div>
          </div>
          <div className={Classes.header}>
            <h4 className={Classes.topic}>{title}</h4>
            <h4 className={Classes.subtopic}>{description}</h4>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
