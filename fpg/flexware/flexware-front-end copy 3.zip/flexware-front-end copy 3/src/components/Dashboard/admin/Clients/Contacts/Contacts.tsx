/* eslint-disable no-nested-ternary */
import React from 'react';
import Classes from './index.module.css';
import FlexModal from '../../../../elements/FlexModal';
import FlexInput from '../../../../elements/FlexInput';
import FlexButton from '../../../../elements/FlexButton';
// eslint-disable-next-line import/no-cycle
import FlexTable from '../../../../elements/FlexTable';
import { ContactsProps } from './types';
import Loader from '../../../../elements/Loader';
// eslint-disable-next-line import/no-cycle

const headers = [
  'FIRST NAME',
  'LAST NAME',
  'DESIGNATION/ROLE',
  'EMAIL',
  'PHONE',
];

const Contacts = ({
  toggleModal,
  showModal,
  setUserState,
  userAuthDetails,
  handleSubmit,
  contacts,
  addingContact,
  fetchingContacts,
}: ContactsProps) => {
  return (
    <div className={Classes.tableContainer}>
      <div className={Classes.tableHeader}>
        <p>Available Contacts</p>
        <div
          className={Classes.accountText}
          onClick={() => toggleModal(!showModal)}
          onKeyPress={() => toggleModal(!showModal)}
          role="button"
          tabIndex={0}
        >
          <div className={Classes.icon}>
            <img
              style={{ width: '14px' }}
              src={`${process.env.PUBLIC_URL}/images/surface.svg`}
              alt="logo"
            />
          </div>
          Add Contact Person
        </div>
      </div>

      {showModal && (
        <FlexModal>
          <div className={Classes.form}>
            <h3
              style={{
                color: '#707070',
                textAlign: 'center',
                fontWeight: 'normal',
              }}
            >
              Add Contact Person
            </h3>
            <FlexInput
              name="firstName"
              placeholder="Elliot"
              label="First Name"
              onChange={setUserState}
              value={userAuthDetails.firstName || ''}
            />
            <FlexInput
              name="lastName"
              placeholder="Rotimi"
              label="Last Name"
              onChange={setUserState}
              value={userAuthDetails.lastName || ''}
            />
            <FlexInput
              name="role"
              placeholder="Accountant"
              label="Designation/Role"
              onChange={setUserState}
              value={userAuthDetails.role || ''}
            />
            <FlexInput
              name="email"
              placeholder="rotimi@gmail.com"
              label="Email Address"
              onChange={setUserState}
              value={userAuthDetails.email || ''}
            />
            <FlexInput
              name="phone"
              placeholder="23490892345"
              label="Phone Number"
              onChange={setUserState}
              value={userAuthDetails.phone || ''}
            />
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-evenly',
                flexDirection: 'row-reverse',
              }}
            >
              <FlexButton
                style={{
                  backgroundColor: 'black',
                  color: 'white',
                  fontWeight: 'normal',
                  width: 'fit-content',
                }}
                type="submit"
                onClick={() => {
                  handleSubmit(userAuthDetails);
                }}
                isLoading={addingContact}
              >
                SUBMIT
              </FlexButton>
              <FlexButton
                style={{
                  backgroundColor: 'white',
                  color: 'black',
                  backgroundImage: 'none',
                  width: 'fit-content',
                }}
                onClick={() => toggleModal(!showModal)}
              >
                Cancel
              </FlexButton>
            </div>
          </div>
        </FlexModal>
      )}
      {fetchingContacts ? (
        <Loader />
      ) : contacts.length > 0 ? (
        <FlexTable headers={headers} data={contacts} />
      ) : (
        <h3 style={{ textAlign: 'center' }}>No Contacts Found</h3>
      )}
    </div>
  );
};
export default Contacts;
