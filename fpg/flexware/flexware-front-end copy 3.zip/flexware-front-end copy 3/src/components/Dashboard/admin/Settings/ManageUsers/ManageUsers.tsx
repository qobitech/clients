import React from 'react';
import ManageUserHeader from './ManageUserHeader';
import {
  managerUserHeader,
  reduceDataForTable,
  manageRoleType,
} from '../../../../../utils/utility';
import Classes from './index.module.css';
import FlexTable from '../../../../elements/FlexTable';

type ManageUserProps = {
  data: manageRoleType[];
  onButtonClick?: () => void;
};
const headers = ['Role', 'Permissions', 'Status'];
const ManageUsers: React.FC<ManageUserProps> = ({ data, onButtonClick }) => (
  <div>
    <div className={Classes.containerBox}>
      <ManageUserHeader
        title={managerUserHeader[0].title}
        subtitle={managerUserHeader[0].subtitle}
        buttontext={managerUserHeader[0].buttontext}
        onButtonClick={onButtonClick}
      />
      <FlexTable
        title="3 User Roles"
        headers={headers}
        data={reduceDataForTable(data)}
      />
    </div>
  </div>
);

export default ManageUsers;
