import React from 'react';
import FlexButton from '../../../../elements/FlexButton';
import Classes from './index.module.css';
import { CompanyProps } from './types';
import Placeholder from '../../../../elements/Placeholder';
import stop from '../../../../svgs/stop.svg';
import write from '../../../../svgs/writing.svg';
import Permissions from '../../../../elements/Permission';

const Company = ({
  numOfServices,
  customerName,
  status,
  gettingClient,
  clientPermission,
}: CompanyProps) => {
  return (
    <div className={Classes.container}>
      <div className={Classes.buttons}>
        <FlexButton
          style={{
            backgroundColor: '#D9D9D9',
            fontWeight: 'normal',
            color: '#6C6C6C',
            marginRight: '7px',
            backgroundImage: 'none',
          }}
        >
          <img src={stop} alt="stop" />
          Enable
        </FlexButton>
        <Permissions permission={['update']} check={clientPermission}>
          <FlexButton
            style={{
              backgroundColor: '#5C7EA5',
              fontWeight: 'normal',
              backgroundImage: 'none',
            }}
          >
            <img src={write} alt="writing" />
            Edit
          </FlexButton>
        </Permissions>
      </div>
      <div className={Classes.left}>
        <div className={Classes.image}>
          {/* <div className={Classes.circle} /> */}
        </div>
        <div className={Classes.details}>
          <div className={Classes.title}>
            {gettingClient ? <Placeholder /> : <div>{customerName}</div>}
          </div>
          <div className={Classes.spanGroup}>
            <div className={Classes.span}>
              <div>status</div>
              {gettingClient ? <Placeholder /> : <div>{status}</div>}
            </div>
            <div className={Classes.span}>
              <div>services</div>
              <div>
                {gettingClient ? <Placeholder /> : <div>{numOfServices}</div>}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Company;
