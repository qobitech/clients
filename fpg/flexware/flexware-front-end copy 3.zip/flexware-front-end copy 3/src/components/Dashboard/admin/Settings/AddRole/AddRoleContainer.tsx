import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import {
  updateBreadCrumbStack,
  updateComapnyDisplayed,
} from '../../../../../actions/app';
import AddRole from './AddRole';

const AddRoleContainer = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(updateComapnyDisplayed('Add New Role'));
    dispatch(
      updateBreadCrumbStack([
        { title: 'Settings', url: '/admin/dashboard/settings' },
        { title: 'User Management', url: '/admin/dashboard/settings/user' },
        {
          title: 'Manage User Roles',
          url: '/admin/dashboard/settings/user/manageusers',
        },
      ]),
    );
  }, [dispatch]);
  useEffect(() => {
    return () => {
      dispatch(updateComapnyDisplayed(''));
      dispatch(updateBreadCrumbStack([]));
    };
  }, [dispatch]);
  return <AddRole />;
};
export default AddRoleContainer;
