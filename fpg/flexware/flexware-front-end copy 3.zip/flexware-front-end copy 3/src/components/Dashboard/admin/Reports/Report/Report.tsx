/* eslint-disable import/no-cycle */
import React from 'react';
import Classes from './index.module.css';
import ReportB from '../ReportB/ReportB';
import { ReportProps } from './types';
import Element from '../../../../elements/Render';
import Div from '../../../../elements/Div';

const Report: React.FC<ReportProps> = ({
  customerName,
  method,
  status,
  date,
  batchRef,
  data,
  format,
}) => {
  return (
    <div className={Classes.container}>
      <div className={Classes.top}>
        <div className={Classes.head}>
          <div className={Classes.company}>{customerName}</div>
          <div className={Classes.date}>
            <span>DATE</span>
            <span>{date}</span>
          </div>
          <div className={Classes.status}>
            <span>STATUS</span>
            <span>
              <Element Component={Div} style={status.style}>
                {status.title}
              </Element>
            </span>
          </div>
        </div>
        <hr className={Classes.horizontal} />
        <div className={Classes.row}>
          <div className={Classes.segment}>
            <div className={Classes.title}>Method</div>
            <div className={Classes.desc}>{method}</div>
          </div>
          <div className={Classes.segment}>
            <div className={Classes.title}>Original format:</div>
            <div className={Classes.desc}>{format}</div>
          </div>
          <div className={Classes.segment}>
            <div className={Classes.title}>Batch Reference:</div>
            <div className={Classes.desc}>{batchRef}</div>
          </div>
        </div>
        {/* <div className={Classes.stats}>
          <div className={Classes.stat}>
            <span className={Classes.pre}>Original format:</span>
            <span className={Classes.suff}>CSV</span>
          </div>
          <div className={Classes.stat}>
            <span className={Classes.pre}>Batch Reference:</span>
            <span className={Classes.suff}>{batchRef}</span>
          </div>
        </div> */}
      </div>
      <div className={Classes.bottom}>
        <ReportB data={data} />
      </div>
    </div>
  );
};
export default Report;
