/* eslint-disable import/no-cycle */
import React from 'react';
import Classes from './index.module.css';
import { manageUserHeaderInterface } from '../../../../../utils/utility';
import FlexButton from '../../../../elements/FlexButton';

const ManageUserHeader = ({
  title,
  subtitle,
  buttontext,
  onButtonClick,
}: manageUserHeaderInterface) => {
  return (
    <div className={Classes.container}>
      <div className={Classes.containRow}>
        <div className={Classes.header}>
          <h4 className={Classes.topic}>{title}</h4>
          <h4 className={Classes.subtopic}>{subtitle}</h4>
        </div>
        {onButtonClick && buttontext ? (
          <FlexButton
            style={{
              backgroundColor: 'black',
              fontSize: '12px',
              marginLeft: 'auto',
              width: '160px',
              height: '1em',
            }}
            onClick={() => onButtonClick && onButtonClick()}
          >
            {buttontext}
          </FlexButton>
        ) : null}
      </div>
    </div>
  );
};

export default ManageUserHeader;
