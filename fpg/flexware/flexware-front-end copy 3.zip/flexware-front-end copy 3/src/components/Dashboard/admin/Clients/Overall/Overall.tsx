/* eslint-disable react/jsx-props-no-spreading */
import React from 'react';
import FlexButton from '../../../../elements/FlexButton';
import BigText from '../../../../elements/BigText';
import Classes from '../index.module.css';
import FlexModal from '../../../../elements/FlexModal';
import FlexInput from '../../../../elements/FlexInput';
import { OverallProps } from './types';
import Message from '../../../../elements/Message';

const Overall = ({
  toggleModal,
  showModal,
  setUserState,
  userAuthDetails,
  addingClient,
  message,
  handleSubmit,
  activeClients,
  inactiveClients,
  shouldShowContinue,
  continueFunc,
}: OverallProps) => {
  return (
    <div className={Classes.innerDiv}>
      <div className={Classes.add}>
        <p className={Classes.caption}>Set up new client</p>
        <FlexButton onClick={() => toggleModal(!showModal)}>
          Add New Client
        </FlexButton>
      </div>
      <div className={Classes.numbers}>
        <div>
          <BigText
            number={activeClients.toString()}
            caption="Active Clients"
            align="center"
            captionAlign="center"
            numberColor="#66697E"
          />
        </div>
        <div className={Classes.partition} />
        <div>
          <BigText
            number={inactiveClients.toString()}
            caption="Inactive Clients"
            align="center"
            captionAlign="center"
            numberColor="#66697E"
          />
        </div>
      </div>
      {showModal && (
        <FlexModal>
          <div className={Classes.form}>
            <h3>Add new client record</h3>
            <FlexInput
              name="ubaCorporateId"
              placeholder="7683798672"
              label="Corporate ID"
              onChange={setUserState}
              value={userAuthDetails.ubaCorporateId || ''}
            />
            <FlexInput
              name="ubaUserId"
              placeholder="9820478675671"
              label="Client ID"
              onChange={setUserState}
              value={userAuthDetails.ubaUserId || ''}
            />
            <FlexInput
              name="customerName"
              placeholder="Oando PLC"
              label="Customer Name"
              onChange={setUserState}
              value={userAuthDetails.customerName || ''}
            />
            <FlexInput
              name="email"
              placeholder="client@company.com"
              label="Email"
              onChange={setUserState}
              value={userAuthDetails.email || ''}
            />
            <FlexInput
              name="phone"
              placeholder="E.g 0908978789"
              label="Phone Number"
              onChange={setUserState}
              value={userAuthDetails.phone || ''}
            />
            <FlexButton
              type="submit"
              onClick={() => {
                handleSubmit(userAuthDetails);
              }}
            >
              Create Client Account
            </FlexButton>
            <FlexButton
              style={{
                backgroundColor: 'white',
                color: 'black',
                fontWeight: 'bold',
                backgroundImage: 'none',
                marginLeft: '20px',
              }}
              onClick={() => toggleModal(!showModal)}
            >
              Cancel
            </FlexButton>
          </div>
          {addingClient && (
            <FlexModal
              type="landscape"
              style={{
                flexDirection: 'column',
                paddingTop: '10px',
              }}
            >
              <Message {...message} />
              {shouldShowContinue && (
                <FlexButton
                  onClick={() => {
                    continueFunc();
                  }}
                  style={{
                    maxWidth: '300px',
                    marginLeft: 'auto',
                    marginRight: 'auto',
                    marginTop: '10px',
                    backgroundColor: '#000000',
                  }}
                >
                  Continue
                </FlexButton>
              )}
            </FlexModal>
          )}
        </FlexModal>
      )}
    </div>
  );
};

export default Overall;
