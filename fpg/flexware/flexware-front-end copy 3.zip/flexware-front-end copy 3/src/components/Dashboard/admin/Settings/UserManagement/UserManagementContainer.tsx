import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import {
  updateBreadCrumbStack,
  updateComapnyDisplayed,
} from '../../../../../actions/app';
import UserManagement from './UserManagement';

const UserManagementContainer = ({
  changeUrl,
}: {
  changeUrl: (arg: string) => void;
}) => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(updateComapnyDisplayed('User Management'));
    dispatch(
      updateBreadCrumbStack([
        { title: 'Settings', url: '/admin/dashboard/settings' },
      ]),
    );
  }, [dispatch]);
  useEffect(() => {
    return () => {
      dispatch(updateComapnyDisplayed(''));
      dispatch(updateBreadCrumbStack([]));
    };
  }, [dispatch]);
  return <UserManagement changeUrl={changeUrl} />;
};
export default UserManagementContainer;
