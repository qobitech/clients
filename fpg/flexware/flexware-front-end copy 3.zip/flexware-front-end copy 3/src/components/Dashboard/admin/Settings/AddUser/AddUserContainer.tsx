import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import {
  updateBreadCrumbStack,
  updateComapnyDisplayed,
} from '../../../../../actions/app';
import AddUser from './AddUser';

const AddUserContainer = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(updateComapnyDisplayed('Add New User'));
    dispatch(
      updateBreadCrumbStack([
        { title: 'Settings', url: '/admin/dashboard/settings' },
        { title: 'User Management', url: '/admin/dashboard/settings/user' },
        {
          title: 'Manage Users',
          url: '/admin/dashboard/settings/user/manageusers',
        },
      ]),
    );
  }, [dispatch]);
  useEffect(() => {
    return () => {
      dispatch(updateComapnyDisplayed(''));
      dispatch(updateBreadCrumbStack([]));
    };
  }, [dispatch]);
  return <AddUser />;
};
export default AddUserContainer;
