import React, { useState } from 'react';
import { useHistory, Route, Switch } from 'react-router-dom';
import Settings from './Settings';
import UserManagement from './UserManagement/UserManagementContainer';
import ManageUsers from './ManageUsers/ManageUsersContainer';
import ManageAdmins from './ManageAdmins/ManageAdminsContainer';
import AddRole from './AddRole/AddRoleContainer';
import AddUser from './AddUser/AddUserContainer';

const SettingsContainer = () => {
  const history = useHistory();
  const [baseUrl] = useState(history.location.pathname);
  const changrUrl = (arg: string) => {
    history.push(`${baseUrl}${arg}`);
  };
  return (
    <Switch>
      <Route
        path={baseUrl}
        exact
        render={() => <Settings changeUrl={changrUrl} />}
      />
      <Route
        path={`${baseUrl}/user`}
        exact
        render={() => <UserManagement changeUrl={changrUrl} />}
      />
      <Route
        path={`${baseUrl}/user/manageusers`}
        exact
        render={() => (
          <ManageUsers
            changeUrl={() => changrUrl('/user/manageusers/adduser')}
          />
        )}
      />
      <Route
        path={`${baseUrl}/user/manageusers/adduser`}
        render={() => <AddRole />}
      />
      <Route
        path={`${baseUrl}/user/manageadmins`}
        exact
        render={() => (
          <ManageAdmins
            changeUrl={() => changrUrl('/user/manageadmins/addrole')}
          />
        )}
      />
      <Route
        path={`${baseUrl}/user/manageadmins/addrole`}
        render={() => <AddUser />}
      />
    </Switch>
  );
};
export default SettingsContainer;
