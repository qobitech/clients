import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useParams } from 'react-router-dom';
import { ReducerTypes } from '../../../../../reducers';
// import { SftpService, RestService } from '../../../../../reducers/interfaces';

import {
  updateComapnyDisplayed,
  updateBreadCrumbStack,
} from '../../../../../actions/app';
import { toggleLiveClient, updateCards } from '../../../../../actions/clients';
import Services from './Services';

const ServicesContainer = () => {
  const dispatch = useDispatch();
  const params: {
    index?: string | undefined;
    service?: any;
  } = useParams();
  const {
    clients: {
      company: { customerName, live, cards, services },
    },
    user: { type },
  } = useSelector((state: ReducerTypes) => state);
  useEffect(() => {
    dispatch(
      updateBreadCrumbStack([
        { title: 'Clients', url: `/${type}/dashboard/clients` },
        {
          title: customerName,
          url: `/${type}/dashboard/clients/company/${params.index}`,
        },
      ]),
    );
  }, [dispatch, customerName, params.index, type]);
  useEffect(() => {
    dispatch(updateComapnyDisplayed(`${params.service.toUpperCase()} Service`));
  }, [dispatch, params.service]);
  useEffect(() => {
    return () => {
      dispatch(updateComapnyDisplayed(''));
      dispatch(updateBreadCrumbStack([]));
    };
  }, [dispatch]);
  const toggleLiveClientStatus = (arg: boolean) => {
    dispatch(toggleLiveClient(arg));
  };
  useEffect(() => {
    if (params.service === 'sftp') {
      const sftpServiceData = services.find(service => service.type === 'sftp');
      dispatch(
        updateCards([
          [
            { title: 'Base Path', credential: sftpServiceData.basePath },
            { title: 'Archive', credential: sftpServiceData.archive },
            {
              title: 'Acknowledgment',
              credential: sftpServiceData.acknowledgement,
            },
          ],
          [{ title: 'Customer ID', credential: sftpServiceData.customerId }],
        ]),
      );
    }
    if (params.service === 'rest') {
      const restServiceData = services.find(service => service.type === 'rest');
      dispatch(
        updateCards([
          [{ title: 'Client ID', credential: restServiceData.clientId }],
          [
            {
              title: 'Client Secret',
              credential: restServiceData.clientSecret,
              secret: true,
            },
          ],
        ]),
      );
    }
  }, [params.service, services, dispatch]);
  return (
    <Services
      live={live}
      toggleLiveClient={(arg?: boolean) => {
        toggleLiveClientStatus(!!arg);
      }}
      fullConfig={cards}
      type={params.service}
    />
  );
};

export default ServicesContainer;
