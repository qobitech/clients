import React from 'react';
import ManageUserHeader from '../ManageUsers/ManageUserHeader';
import {
  managerUserHeader,
  reduceDataForTable,
  manageAdminType,
} from '../../../../../utils/utility';
// import Classes from '../index.module.css';
import Classes from '../ManageUsers/index.module.css';
import FlexTable from '../../../../elements/FlexTable';

type ManageAdminProps = {
  data: manageAdminType[];
  onButtonClick?: () => void;
};
const headers = ['Name', 'User ID', 'Role', 'Status'];
const ManageAdmins: React.FC<ManageAdminProps> = ({ data, onButtonClick }) => (
  <div>
    <div className={Classes.containerBox}>
      <ManageUserHeader
        title={managerUserHeader[1].title}
        subtitle={managerUserHeader[1].subtitle}
        buttontext={managerUserHeader[1].buttontext}
        onButtonClick={onButtonClick}
      />
      <FlexTable
        title="3 Admin users"
        headers={headers}
        data={reduceDataForTable(data)}
      />
    </div>
  </div>
);

export default ManageAdmins;
