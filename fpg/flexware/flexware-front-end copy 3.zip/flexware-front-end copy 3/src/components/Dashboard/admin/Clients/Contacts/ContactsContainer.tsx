/* eslint-disable import/no-cycle */
import React, { useState, ChangeEvent, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Contacts from './Contacts';
import {
  FETCH_CONTACTS_SUCCEEDED,
  FETCH_CONTACTS_REQUESTED,
  FETCH_CONTACTS_FAILED,
} from '../../../../../actions/types';
import { ReducerTypes } from '../../../../../reducers';
import api from '../../../../../utils/api';
import { reduceDataForTable } from '../../../../../utils/utility';

const ContactsContainer = ({ path }: { path: string }) => {
  const dispatch = useDispatch();
  const {
    clients: {
      addingClient,
      company: { id },
      contacts,
      fetchingContacts,
    },
    user: { token },
  } = useSelector((state: ReducerTypes) => state);
  const [showModal, toggleModal] = useState(false);
  const [isFetching, toggleFetching] = useState(false);
  const [addingContact, togleAddingContact] = useState(false);
  const [userAuthDetails, updateUserAuthDetails] = useState<any>({});
  const setUserState = (event: ChangeEvent<HTMLInputElement>) => {
    updateUserAuthDetails({
      ...userAuthDetails,
      [event.target.name]: event.target.value,
    });
  };

  const contactsForTable: any[] = reduceDataForTable(
    contacts.reduce((accumulator: any[], value) => {
      const obj: any = {};
      obj.firstName = value.firstName;
      obj.lastname = value.lastName;
      obj.role = value.role;
      obj.email = value.email;
      obj.phone = value.phone;
      accumulator.push(obj);
      return accumulator;
    }, []),
  );

  useEffect(() => {
    dispatch({ type: FETCH_CONTACTS_REQUESTED });
    api
      .get(`/contacts/${id}`, token)
      .then(data => {
        dispatch({ type: FETCH_CONTACTS_SUCCEEDED, payload: data });
      })
      .catch(err => {
        dispatch({ type: FETCH_CONTACTS_FAILED });
      });
  }, [dispatch, id, token]);

  const handleAddClient = (arg: any) => {
    toggleFetching(!isFetching);
    togleAddingContact(true);
    api
      .post('/contacts', { ...userAuthDetails, userId: id }, token)
      .then(data => {
        dispatch({
          type: FETCH_CONTACTS_SUCCEEDED,
          payload: [...contacts, userAuthDetails],
        });
        togleAddingContact(false);
        toggleModal(!showModal);
      })
      .catch(() => {
        toggleModal(!showModal);
      });
  };
  return (
    <Contacts
      path={path}
      showModal={showModal}
      toggleModal={toggleModal}
      setUserState={setUserState}
      userAuthDetails={userAuthDetails}
      handleSubmit={handleAddClient}
      addingClient={addingClient}
      contacts={contactsForTable}
      addingContact={addingContact}
      fetchingContacts={fetchingContacts}
    />
  );
};

export default ContactsContainer;
