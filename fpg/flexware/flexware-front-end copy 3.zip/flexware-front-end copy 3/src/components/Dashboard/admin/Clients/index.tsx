/* eslint-disable react/jsx-props-no-spreading */
import React from 'react';
import { Switch, Route, match } from 'react-router-dom';
import Classes from './index.module.css';
import Overall from './Overall/OverallContainer';
import Company from './Company/CompanyContainer';
import FlexTabs from '../../../elements/FlexTabs';
import Services from './Services/SercicesContainer';
import Recent from './Recent';

const Clients = ({ match: routeMatch }: { match: match }) => {
  return (
    <div className={Classes.container}>
      <Switch>
        <Route
          path={`${routeMatch.path}/company/:index/services/:service`}
          exect
          component={Services}
        />
        <div>
          <div className={Classes.list}>
            <Switch>
              <Route
                path={`${routeMatch.path}/`}
                exact
                render={() => <Overall path={routeMatch.path} />}
              />
              <Route path={`${routeMatch.path}/`} exact component={Company} />
              <Route
                path={`${routeMatch.path}/company/:index`}
                exact
                component={Company}
              />
              <Route
                path={`${routeMatch.path}/company`}
                exact
                component={Company}
              />
            </Switch>
          </div>
          <Switch>
            <Route
              path={`${routeMatch.path}/`}
              exact
              render={() => <Recent />}
            />
            <Route
              path={`${routeMatch.path}/company/:index`}
              exact
              render={() => <FlexTabs />}
            />
            <Route
              path={`${routeMatch.path}/company`}
              exact
              render={() => <FlexTabs />}
            />
          </Switch>
        </div>
      </Switch>
    </div>
  );
};

export default Clients;
