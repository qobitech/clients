import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useParams } from 'react-router-dom';
import {
  updateComapnyDisplayed,
  getCompany,
  updateBreadCrumbStack,
} from '../../../../../actions/app';
import { ReducerTypes } from '../../../../../reducers';
import Company from './Company';

const CompanyContainer = () => {
  const dispatch = useDispatch();
  const {
    clients: {
      company: { customerName, status, numOfservices },
      recentClients,
      gettingClient,
    },
    user: {
      token,
      type,
      permissions: { client },
    },
  } = useSelector((state: ReducerTypes) => state);
  const params: { index?: string | undefined } = useParams();
  useEffect(() => {
    customerName && dispatch(updateComapnyDisplayed(customerName));
  }, [customerName, dispatch]);

  useEffect(() => {
    if (params.index || params.index === '0') {
      dispatch(getCompany(recentClients[Number(params.index)].id, token));
    }
  }, [dispatch, params.index, recentClients, token]);

  useEffect(() => {
    dispatch(
      updateBreadCrumbStack([
        { title: 'Clients', url: `/${type}/dashboard/clients` },
      ]),
    );
  }, [dispatch, type]);

  useEffect(() => {
    return () => {
      dispatch(updateComapnyDisplayed(''));
      dispatch(updateBreadCrumbStack([]));
    };
  }, [dispatch]);
  return (
    <Company
      customerName={customerName}
      numOfServices={numOfservices}
      status={status}
      gettingClient={gettingClient}
      clientPermission={client}
    />
  );
};

export default CompanyContainer;
