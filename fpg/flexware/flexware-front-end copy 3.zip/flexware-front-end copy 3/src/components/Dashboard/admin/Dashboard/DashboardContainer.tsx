import React from 'react';
import { useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { ReducerTypes } from '../../../../reducers';
import Dashboard from './Dashboard';

const DashBoardContainer = () => {
  const history = useHistory();
  const {
    user: { type, numberOfActiveClients },
    clients: { recentClients },
  } = useSelector((state: ReducerTypes) => state);
  const calcNum = recentClients.filter(client => client.status).length;
  const activeClients =
    calcNum > numberOfActiveClients ? calcNum : numberOfActiveClients;
  const inactiveClients = recentClients.length - activeClients;

  return (
    <Dashboard
      type={type}
      history={history}
      activeClients={activeClients}
      inactiveClients={inactiveClients}
    />
  );
};

export default DashBoardContainer;
