export type statusType = 'active' | 'inactive';
export interface CompanyProps {
  customerName: string;
  status: statusType;
  numOfServices: number;
  gettingClient: boolean;
  clientPermission: number;
}
