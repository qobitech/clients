import { ChangeEvent } from 'react';
import { formTypes } from '../../../../Auth/types';
import { MessageTypes } from '../../../../elements/Message/types';

export interface OverallProps {
  path?: string;
  toggleModal: (arg: boolean) => void;
  showModal: boolean;
  setUserState?: (event: ChangeEvent<HTMLInputElement>) => void;
  userAuthDetails: { [key in formTypes]: string };
  handleSubmit: (arg: any) => void;
  cleanUp?: () => void;
  message: MessageTypes;
  addingClient?: boolean;
  activeClients: number;
  inactiveClients: number;
  continueFunc: () => void;
  shouldShowContinue: boolean;
}
