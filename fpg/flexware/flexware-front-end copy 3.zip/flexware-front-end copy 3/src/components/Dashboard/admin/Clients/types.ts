export interface ClientProps {
  showModal: boolean;
  toggleModal: boolean;
}
