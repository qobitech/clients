/* eslint-disable no-nested-ternary */
/* eslint-disable import/no-cycle */
import React from 'react';
import Classes from './index.module.css';
import FlexModal from '../../../../elements/FlexModal';
import FlexInput from '../../../../elements/FlexInput';
import FlexButton from '../../../../elements/FlexButton';
import FlexTable from '../../../../elements/FlexTable';
import { AccountsProps } from './types';
import { reduceDataForTable } from '../../../../../utils/utility';
import Loader from '../../../../elements/Loader';

const headers = ['ACCOUNT NUMBER', 'ACCOUNT Name'];
const Accounts = ({
  toggleModal,
  showModal,
  setUserState,
  userAuthDetails,
  handleSubmit,
  accounts,
  addingAccount,
  fetchingAccounts,
  verifyAccount,
  accountVerified,
  verifyingAccount,
}: AccountsProps) => {
  return (
    <div className={Classes.tableContainer}>
      <div className={Classes.tableHeader}>
        <p>Available Accounts</p>
        <div className={Classes.float}>
          <div className={Classes.search}>
            <FlexInput
              name="search"
              placeholder="Type to Search"
              style={{
                height: '30px',
                backgroundColor: '#d9d9d9',
              }}
            />
          </div>
          <div
            className={Classes.accountText}
            onClick={() => toggleModal(!showModal)}
            role="button"
            onKeyPress={() => toggleModal(!showModal)}
            tabIndex={0}
          >
            <div className={Classes.icon}>
              <img
                style={{ width: '14px' }}
                src={`${process.env.PUBLIC_URL}/images/surface.svg`}
                alt="logo"
              />
            </div>
            Add Account
          </div>
        </div>
      </div>

      {showModal && (
        <FlexModal
          fit
          style={{ minHeight: '300px', width: '400px', padding: '50px' }}
          // cleanUp={}
        >
          <div className={Classes.form}>
            <h3>Add Account</h3>
            <FlexInput
              name="accountNumber"
              placeholder="234567453234"
              label="Account Number"
              onChange={setUserState}
              disabled={accountVerified}
              value={userAuthDetails.accountNumber || ''}
            />
            {accountVerified && (
              <>
                <FlexInput
                  disabled
                  // placeholder="Oando PLC Procurements"
                  label="Account Name"
                  value={userAuthDetails.accountName}
                />
                <FlexInput
                  disabled
                  // placeholder="procurements@oandoplc.com"
                  label="Account Email"
                  value={userAuthDetails.email}
                />
                <FlexInput
                  disabled
                  // placeholder="procurements@oandoplc.com"
                  label="Phone Number"
                  value={userAuthDetails.phone}
                />
              </>
            )}
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-evenly',
                flexDirection: 'row-reverse',
              }}
            >
              <FlexButton
                style={{
                  backgroundColor: 'black',
                  color: 'white',
                  fontWeight: 'normal',
                  width: 'fit-content',
                }}
                type="submit"
                onClick={
                  !addingAccount
                    ? accountVerified
                      ? () => {
                          handleSubmit(userAuthDetails);
                        }
                      : () => {
                          verifyAccount(true);
                        }
                    : () => null
                }
                isLoading={addingAccount || verifyingAccount}
              >
                {accountVerified ? 'Add Account' : 'Fetch Data'}
              </FlexButton>
              <FlexButton
                style={{
                  backgroundColor: 'white',
                  color: 'black',
                  backgroundImage: 'none',
                  width: 'fit-content',
                }}
                onClick={() => toggleModal(!showModal)}
              >
                Cancel
              </FlexButton>
            </div>
          </div>
        </FlexModal>
      )}
      {fetchingAccounts ? (
        <Loader />
      ) : accounts.length > 0 ? (
        <FlexTable
          headers={headers}
          data={reduceDataForTable(accounts)}
          style={{ borderTop: 'none' }}
        />
      ) : (
        <h3 style={{ textAlign: 'center' }}>No Accounts Found</h3>
      )}
    </div>
  );
};
export default Accounts;
