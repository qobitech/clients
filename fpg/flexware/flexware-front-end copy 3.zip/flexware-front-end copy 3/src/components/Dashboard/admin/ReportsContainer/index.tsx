import React from 'react';
import Reports from '../Reports';
import Classes from './index.module.css';
import { fakeData } from '../../../../utils/utility';

const ReportsConatiner = () => (
  <div className={Classes.container}>
    <Reports data={fakeData} />
  </div>
);

export default ReportsConatiner;
