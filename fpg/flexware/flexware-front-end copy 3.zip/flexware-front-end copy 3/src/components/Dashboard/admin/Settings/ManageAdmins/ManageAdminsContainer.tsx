import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import {
  updateBreadCrumbStack,
  updateComapnyDisplayed,
} from '../../../../../actions/app';
import ManageAdmins from './ManageAdmins';
import { manageAdminData } from '../../../../../utils/utility';

const ManageAdminsContainer = ({ changeUrl }: { changeUrl: () => void }) => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(updateComapnyDisplayed('Manage Users'));
    dispatch(
      updateBreadCrumbStack([
        { title: 'Settings', url: '/admin/dashboard/settings' },
        { title: 'User Management', url: '/admin/dashboard/settings/user' },
      ]),
    );
  }, [dispatch]);
  useEffect(() => {
    return () => {
      dispatch(updateComapnyDisplayed(''));
      dispatch(updateBreadCrumbStack([]));
    };
  }, [dispatch]);
  return <ManageAdmins data={manageAdminData} onButtonClick={changeUrl} />;
};

export default ManageAdminsContainer;
