/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable import/no-cycle */
import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { ReducerTypes } from '../../../../../reducers';
import Report from './Report';
import {
  updateBreadCrumbStack,
  updateComapnyDisplayed,
} from '../../../../../actions/app';
// import { batchType, getStatusObject } from '../../../../../utils/utility';

const ReportContainer = () => {
  const params = useParams<{ id: string }>();
  const {
    reports: { recentTransactions },
  } = useSelector((state: ReducerTypes) => state);
  const currTtansaction = recentTransactions[Number(params.id)];
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(updateComapnyDisplayed(currTtansaction.referenceNo));
    dispatch(
      updateBreadCrumbStack([
        { title: 'Reports', url: '/admin/dashboard/reports' },
      ]),
    );
    // api.get('/transactions/52/get', token).then(data => console.log(data));
  }, [dispatch, currTtansaction.referenceNo]);
  useEffect(() => {
    return () => {
      dispatch(updateComapnyDisplayed(''));
      dispatch(updateBreadCrumbStack([]));
    };
  }, [dispatch]);

  // const sample = {
  //   product_code: 'SALARY PAY',
  //   debit_account: 1015214165,
  //   amount: '500,000',
  //   currency: 'NGN',
  //   beneficiary_code: 'EMP101',
  //   beneficiary_name: 'Micheal Uzomah',
  //   narration: 'September Salary Day',
  //   status: { title: 'successful', style: { color: '#5CA594' } },
  // };

  const data = currTtansaction.transactionDetails;

  // const fillData = data.reduce((acc: batchType[], curr): batchType[] => {
  //   acc.push({
  //     ...sample,
  //     currency: curr.currency || 'NGN',
  //     amount: curr.amount || '500,000',
  //     status: getStatusObject(curr.status),
  //   });
  //   return acc;
  // }, []);

  return (
    <div>
      <Report
        customerName={currTtansaction.customerName}
        status={currTtansaction.status}
        date={currTtansaction.date}
        batchRef={currTtansaction.referenceNo}
        data={data}
        format={currTtansaction.format}
        method={currTtansaction.method}
      />
    </div>
  );
};
export default ReportContainer;
