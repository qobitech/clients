/* eslint-disable import/no-cycle */
import React from 'react';

import FlexTable from '../../../../elements/FlexTable';
import { reduceDataForTable, batchType } from '../../../../../utils/utility';

type ReportBProps = {
  data: batchType[];
};
// const headers = [
//   'PRODUCT CODE',
//   'DEBIT ACCOUNT',
//   'AMOUNT',
//   'CUR.',
//   'BENE. CODE',
//   'BENE. NAME',
//   'NARRATION',
//   'STATUS',
// ];

const ReportBContainer: React.FC<ReportBProps> = ({ data }) => {
  const headers =
    data.length > 0
      ? Object.keys(data[0]).map(header => {
          return header.replace('_', ' ').toUpperCase();
        })
      : [];

  return (
    <div>
      {data.length > 0 ? (
        <FlexTable headers={headers} data={reduceDataForTable(data)} />
      ) : (
        <h3 style={{ textAlign: 'center' }}>No Transactions Yet</h3>
      )}
    </div>
  );
};

export default ReportBContainer;
