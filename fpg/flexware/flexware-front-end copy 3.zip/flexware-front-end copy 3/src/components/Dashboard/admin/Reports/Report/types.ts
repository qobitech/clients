// eslint-disable-next-line import/no-cycle
// import { extraData } from '../../../../../utils/utility';

export interface ReportProps {
  customerName: string;
  //   method: string;
  status: any;
  date: string;
  batchRef: string;
  data: any;
  format: string;
  method: string;
}
