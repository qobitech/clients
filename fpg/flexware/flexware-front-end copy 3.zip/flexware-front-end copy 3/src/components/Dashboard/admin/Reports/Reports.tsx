/* eslint-disable import/no-cycle */
import React from 'react';
import { RecentTrasactionType } from '../../../../reducers/reports';
// import { Switch, Route, match } from 'react-router-dom';
import Loader from '../../../elements/Loader';
import FlexTable from '../../../elements/FlexTable';
import { reduceDataForTable } from '../../../../utils/utility';

type ReportsProps = {
  data: RecentTrasactionType[];
  onRowClick: (arg: number) => void;
  loading?: boolean;
};
const headers = [
  'Client',
  'Transaction Type',
  'Batch Reference',
  // 'Method',
  'Status',
  'Date',
];

const ReportsContainer: React.FC<ReportsProps> = ({
  data,
  onRowClick,
  loading,
}) => (
  <div>
    {loading ? (
      <Loader />
    ) : (
      <FlexTable
        headers={headers}
        data={reduceDataForTable(data, headers.length)}
        title="Recent Transactions"
        onRowClick={onRowClick}
        // rowEditable
      />
    )}
  </div>
);

export default ReportsContainer;
