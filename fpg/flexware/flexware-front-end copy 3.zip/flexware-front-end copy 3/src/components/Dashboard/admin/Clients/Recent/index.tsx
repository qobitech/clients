/* eslint-disable react/jsx-curly-newline */

import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';
import api from '../../../../../utils/api';
import { addToCompanyList } from '../../../../../actions/clients';
import { ReducerTypes } from '../../../../../reducers';
import FlexTable from '../../../../elements/FlexTable';
import { reduceDataForTable } from '../../../../../utils/utility';
import Loader from '../../../../elements/Loader';

const RecentClients: React.FC<{ data?: any }> = () => {
  const {
    user: { token },
    clients: { recentClients },
  } = useSelector((state: ReducerTypes) => state);
  const history = useHistory();
  const dispatch = useDispatch();
  const [isFetcheding, setIsFetching] = useState(false);
  useEffect(() => {
    setIsFetching(true);
    api
      .get('/customers', token)
      .then(data => {
        setIsFetching(false);
        dispatch(addToCompanyList(data));
      })
      .catch(err => {
        setIsFetching(false);
      });
  }, [dispatch, token]);
  return isFetcheding ? (
    <Loader />
  ) : (
    <div>
      {recentClients.length > 0 ? (
        <FlexTable
          headers={['Client Name', 'Date Created', 'Client ID', 'Status']}
          data={reduceDataForTable(recentClients, 4)}
          title="Recent Clients"
          onRowClick={index =>
            history.push(`${history.location.pathname}/company/${index}`)
          }
        />
      ) : (
        <h3 style={{ textAlign: 'center' }}>No Recent Clients</h3>
      )}
    </div>
  );
};

export default RecentClients;
