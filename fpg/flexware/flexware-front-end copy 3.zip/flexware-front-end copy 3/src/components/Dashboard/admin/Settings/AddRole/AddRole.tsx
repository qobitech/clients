import React from 'react';
import Classes from './index.module.css';
import ManageUserHeader from '../ManageUsers/ManageUserHeader';
import FlexInput from '../../../../elements/FlexInput';
import FlexButton from '../../../../elements/FlexButton';

const AddRole = () => {
  return (
    <div className={Classes.wrapper}>
      <div className={Classes.container}>
        <div className={Classes.header}>
          <ManageUserHeader
            title="Add new role"
            subtitle="set up new domain account"
          />
        </div>
        <div className={Classes.divContain}>
          <div className={Classes.rowContain}>
            <p className={Classes.text}>Enter Role details</p>
            <FlexInput
              type="text"
              name="role"
              label="Role Name"
              placeholder="E.g Technical Personnel"
              style={{ marginBottom: '40px' }}
            />
            <p className={Classes.text}>Select Permissions</p>
            <div className={Classes.checkContain}>
              <input type="checkbox" name="" />
              Create
              <input type="checkbox" name="" style={{ marginLeft: '40px' }} />
              Read
              <input type="checkbox" name="" style={{ marginLeft: '40px' }} />
              Update
              <input type="checkbox" name="" style={{ marginLeft: '40px' }} />
              Delete
            </div>
            <FlexButton
              style={{
                backgroundColor: 'black',
                color: 'white',
                width: '60%',
                marginTop: '50px',
              }}
            >
              Add New Role
            </FlexButton>
          </div>
        </div>
      </div>
    </div>
  );
};
export default AddRole;
