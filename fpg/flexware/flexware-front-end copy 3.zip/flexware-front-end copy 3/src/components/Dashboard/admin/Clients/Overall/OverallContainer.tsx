import React, { useState, ChangeEvent } from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
// import ActivityWrapper from '../../../../elements/ActivityWrapper';
import Overall from './Overall';
import api from '../../../../../utils/api';
import { MessageTypes } from '../../../../elements/Message/types';
import { ReducerTypes } from '../../../../../reducers';
import { addClient, addToCompanyList } from '../../../../../actions/clients';
import { ReactComponent as Verified } from './svgs/verified.svg';
import { ReactComponent as Multiply } from './svgs/multiply.svg';
import { GET_CLIENT_SUCCEEDED } from '../../../../../actions/types';

const OverallContainer = ({ path }: { path: string }) => {
  const dispatch = useDispatch();
  const history = useHistory();
  const {
    user: { token },
    clients: { recentClients },
  } = useSelector((state: ReducerTypes) => state);
  const [showModal, toggleModal] = useState(false);
  const [addingClient, setAddingClient] = useState<boolean>(false);
  const [shouldShowContinue, showContinue] = useState<boolean>(false);
  const [message, setMessage] = useState<MessageTypes>({
    header: 'Adding new client record',
    imgUrl: '',
    alt: 'failed',
    message: 'Adding new record',
    caption: 'Processing...',
  });
  const [userAuthDetails, updateUserAuthDetails] = useState<any>({});
  const setUserState = (event: ChangeEvent<HTMLInputElement>) => {
    updateUserAuthDetails({
      ...userAuthDetails,
      [event.target.name]: event.target.value,
    });
  };
  const cleanUp = () => {
    updateUserAuthDetails({});
  };

  const handleAddClient = () => {
    const delay = 3000;
    setAddingClient(true);
    api
      .post('/users', userAuthDetails, token)
      .then((data: any) => {
        if (!data.error) {
          setMessage({
            ...message,
            imgUrl: Verified,
            message: 'Account created successfully',
            caption: '',
          });
          dispatch(addClient(data));
          dispatch({ type: GET_CLIENT_SUCCEEDED, payload: data });
          dispatch(
            addToCompanyList([
              ...recentClients,
              {
                customerName: data.customerName,
                dateCreated: new Date().toISOString(),
                id: data.user.userId,
                numId: data.id,
              },
            ]),
          );
          showContinue(true);
          // setTimeout(() => {
          //   setAddingClient(false);
          //   history.push(`${path}/company/`);
          // }, delay);
        } else {
          setMessage({
            ...message,
            imgUrl: Multiply,
            message: 'Failed to create account',
          });
          setTimeout(() => {
            setAddingClient(false);
          }, delay);
        }
      })
      .catch(() => {
        setMessage({
          ...message,
          imgUrl: Multiply,
          message: 'Failed to create account',
        });
        setTimeout(() => {
          setAddingClient(false);
        }, delay);
      });
  };
  const activeClients = recentClients.filter(client => client.status).length;
  const inactiveClients = recentClients.length - activeClients;
  return (
    <>
      {/* <ActivityWrapper> */}
      <Overall
        path={path}
        showModal={showModal}
        toggleModal={toggleModal}
        setUserState={setUserState}
        userAuthDetails={userAuthDetails}
        handleSubmit={handleAddClient}
        cleanUp={cleanUp}
        addingClient={addingClient}
        message={message}
        activeClients={activeClients}
        inactiveClients={inactiveClients}
        continueFunc={() => history.push(`${path}/company/0`)}
        shouldShowContinue={shouldShowContinue}
      />
      {/* </ActivityWrapper> */}
    </>
  );
};

export default OverallContainer;
