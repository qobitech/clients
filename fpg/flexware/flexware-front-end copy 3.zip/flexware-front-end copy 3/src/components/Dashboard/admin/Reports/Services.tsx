/* eslint-disable import/no-cycle */
import React from 'react';
import { useSelector } from 'react-redux';
import { useLocation, useHistory } from 'react-router-dom';
import { ReducerTypes } from '../../../../reducers';
import Classes from './index.module.css';
// eslint-disable-next-line import/no-cycle
import FlexTable from '../../../elements/FlexTable';
// eslint-disable-next-line import/no-cycle
import { reduceDataForTable, extraData } from '../../../../utils/utility';
// import { eitherService } from '../../../../reducers/interfaces';
// import { serviceType } from '../Clients/Services/Services';
// import Badge from '../../../elements/Badge';

// interface ServiceType {
//   id: string;
//   keyType: serviceType;
//   // dateGenerated: string;
//   status: 'active' | 'inactive' | extraData;
// }
const getStatusObject = (status: extraData): extraData => {
  if (typeof status === 'string') {
    if (status.toLowerCase() === 'pending') {
      return { title: 'Pending', style: { color: '#FFBF67' } };
    }
    if (status.toLowerCase() === 'successful') {
      return { title: 'Successful', style: { color: '#5CA594' } };
    }
    if (status.toLowerCase() === 'active') {
      return { title: 'active', style: { color: '#5CA594' } };
    }
    if (status.toLowerCase() === 'failed') {
      return { title: 'Failed', style: { color: '#FF9595' } };
    }
    if (status.toLowerCase() === 'inactive') {
      return { title: 'inactive', style: { color: '#FF9595' } };
    }
  }
  return { title: 'Pending', style: { color: '#FFBF67' } };
};

// const datsa: ServiceType[] = [
//   {
//     id: 'ee32-122a-d3f0-0132',
//     keyType: 'sftp',
//     status: getStatusObject('active'),
//   },
//   {
//     id: 'ee32-122a-d3f0-0132',
//     keyType: 'soap',
//     status: getStatusObject('active'),
//   },
//   {
//     id: 'ee32-122a-d3f0-0132',
//     keyType: 'rest',
//     status: getStatusObject('active'),
//   },
// ];

const headers: string[] = ['SERVICE TYPE', 'STATUS'];

const Services = () => {
  const location = useLocation();
  const history = useHistory();
  const {
    clients: {
      company: { services },
    },
  } = useSelector((state: ReducerTypes) => state);
  const data = [...services].reduce((accumulator, currentValue) => {
    accumulator.push({
      // id: currentValue.customerId,
      name: currentValue.type,
      // mode: currentValue.name,
      // type: currentValue.type,
      status: getStatusObject('active'),
    });
    return accumulator;
  }, []);
  return (
    <div className={Classes.tableContainer}>
      <FlexTable
        headers={headers}
        data={reduceDataForTable(data)}
        title="Available Services"
        onRowClick={i => {
          history.push(`${location.pathname}/services/${data[i].name}`);
        }}
      />
    </div>
  );
};

export default Services;
