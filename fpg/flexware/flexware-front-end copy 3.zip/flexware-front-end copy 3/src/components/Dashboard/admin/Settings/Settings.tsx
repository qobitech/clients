import React from 'react';
import Setting from './Setting';
import Classes from './index.module.css';
import { settingsList } from '../../../../utils/utility';

const Settings = ({ changeUrl }: { changeUrl: (arg: string) => void }) => (
  <div className={Classes.container}>
    {settingsList.map(setting => (
      <div key={setting.title}>
        <Setting
          title={setting.title}
          description={setting.description}
          url={setting.url}
          onClick={() => changeUrl(setting.url)}
        />
      </div>
    ))}
  </div>
);
export default Settings;
