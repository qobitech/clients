import React, { useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import {
  adminNavRouteDetails,
  clientNavRouteDetails,
  adminNavRouteOrder,
} from '../../../utils/utility';
import { changeCurrentTab } from '../../../actions/app';
import { ReducerTypes } from '../../../reducers';
import { SideNavContainerTypes } from './types';
import SideNav from './SideNav';

const SideNavContainer: React.FC<SideNavContainerTypes> = ({
  navOpen,
  toggleNav,
}: SideNavContainerTypes) => {
  const history = useHistory();
  const dispatch = useDispatch();
  const {
    user: { type },
  } = useSelector((state: ReducerTypes) => state);
  useEffect(() => {
    dispatch(
      changeCurrentTab(history.location.pathname.split('/')[3] || 'dashboard'),
    );
  }, [dispatch, history.location.pathname]);

  let links: [string, { title: string; url?: string | undefined }][];
  if (type === 'admin') {
    links = adminNavRouteOrder.reduce((accumulator, currentValue) => {
      accumulator.push([currentValue, adminNavRouteDetails[currentValue]]);
      return accumulator;
    }, []);
  } else {
    links = Object.entries(clientNavRouteDetails);
  }

  const changeTab = (newTab: string) => {
    dispatch(changeCurrentTab(newTab));
  };

  return (
    <SideNav
      changeTab={changeTab}
      type={type}
      links={links}
      navOpen={navOpen}
      toggleNav={toggleNav}
    />
  );
};

export default SideNavContainer;
