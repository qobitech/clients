import React from 'react';
import { allRoutes } from '../../../reducers/app';
import { userTypes } from '../../../reducers/user';
import { navRouteDetailsType } from '../../../utils/utility';

export interface SideNavContainerTypes {
  navOpen: boolean;
  toggleNav: React.Dispatch<React.SetStateAction<boolean>>;
}

export interface SideNavTypes extends SideNavContainerTypes {
  changeTab: (arg: string) => any;
  type: userTypes;
  links: navRouteDetailsType;
}
