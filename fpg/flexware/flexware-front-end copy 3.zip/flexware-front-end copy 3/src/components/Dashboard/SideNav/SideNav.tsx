import React from 'react';
import { useDispatch } from 'react-redux';
import Classes from './index.module.css';
import SideNavLink from '../../elements/SideNavLink';
import { SideNavTypes } from './types';
import { LOG_OUT } from '../../../actions/types';
import { ReactComponent as LogoutIcon } from './svgs/logout.svg';

const SideNav: React.FC<SideNavTypes> = ({
  navOpen,
  changeTab,
  type,
  links,
}: SideNavTypes) => {
  const dispatch = useDispatch();
  return (
    <div className={`${Classes.container} ${navOpen && Classes.active}`}>
      <div className={Classes.placeholder}>
        <img
          src={`${process.env.PUBLIC_URL}/images/logo-white.svg`}
          alt="logo"
        />
      </div>
      <ul>
        {links.length > 0 ? (
          links.map(link => (
            <>
              <li key={link[1].title}>
                <SideNavLink
                  to={`/${type}/dashboard${link[1].url || `/${link[0]}`}`}
                  name={link[0]}
                  onClick={() => changeTab(link[0])}
                  icon={link[1].icon}
                >
                  {link[1].title}
                </SideNavLink>
              </li>
            </>
          ))
        ) : (
          <div>Something went wrong</div>
        )}
        <li className={Classes.logout}>
          <SideNavLink
            to="/"
            name="Logout"
            onClick={() => {
              localStorage.removeItem('token');
              dispatch({ type: LOG_OUT });
            }}
            icon={LogoutIcon}
          >
            Logout
          </SideNavLink>
        </li>
      </ul>
    </div>
  );
};

export default SideNav;
