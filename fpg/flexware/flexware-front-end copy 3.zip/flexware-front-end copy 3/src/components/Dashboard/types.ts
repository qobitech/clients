import { match } from 'react-router-dom';
import { SideNavContainerTypes } from './SideNav/types';

export declare interface DashboardTypes extends SideNavContainerTypes {
  type: string;
  match: match<{}>;
  breadCrumbStack?: any;
  updateBreadCrumbByIndex: (arg: any) => void;
}
