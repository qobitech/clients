import React, { useState, useEffect } from 'react';
import { RouteComponentProps, useHistory } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import {
  updateBreadCrumbStack,
  updateComapnyDisplayed,
} from '../../actions/app';
import { ReducerTypes } from '../../reducers';
import Dashboard from './Dashboard';

const DashboardContainer = ({ match }: RouteComponentProps) => {
  const {
    user: { type },
    app: { breadCrumbStack, companyDisplayed },
  } = useSelector((state: ReducerTypes) => state);

  const dispatch = useDispatch();

  const updateBreadCrumbByIndex = (index: number) => {
    dispatch(updateBreadCrumbStack([...breadCrumbStack].slice(0, index)));
  };

  const history = useHistory();
  const urlLocation = history.location.pathname.split('/')[3];
  useEffect(() => {
    !companyDisplayed && dispatch(updateComapnyDisplayed(urlLocation));
  }, [dispatch, companyDisplayed, urlLocation]);
  const [navOpen, toggeleNav] = useState<boolean>(false);
  return (
    <Dashboard
      type={type}
      navOpen={navOpen}
      toggleNav={toggeleNav}
      match={match}
      breadCrumbStack={breadCrumbStack}
      updateBreadCrumbByIndex={updateBreadCrumbByIndex}
    />
  );
};

export default DashboardContainer;
