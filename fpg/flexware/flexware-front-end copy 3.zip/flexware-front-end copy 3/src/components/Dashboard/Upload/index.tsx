import React from 'react';
import FlexButton from '../../elements/FlexButton';
import Classes from './index.module.css';
import FlexCard from '../../elements/FlexCard/FlexCardContainer';

const Upload: React.FC = () => {
  return (
    <div className={Classes.container}>
      <div className={Classes.cards}>
        <FlexCard title="Set Up REST Service">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo itaque
          voluptatem sequi neque corrupti? Maiores saepe quisquam modi cum et
          ducimus excepturi, molestias laudantium?
        </FlexCard>
        <FlexCard
          title="Set Up REST Service"
          forward={{ title: 'Go to integration  >', src: '/integration' }}
        >
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo itaque
          voluptatem sequi neque corrupti? Maiores saepe quisquam modi cum et
          ducimus excepturi, molestias laudantium?
        </FlexCard>
      </div>
      <div className={Classes.service}>
        <div className={Classes.notif}>
          <h2>SFTP Service</h2>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo itaque
          voluptatem sequi neque corrupti?
        </div>
        <div className={Classes.button}>
          <FlexButton type="button" onClick={() => ''}>
            Go to file Upload
          </FlexButton>
        </div>
      </div>
    </div>
  );
};

export default Upload;
