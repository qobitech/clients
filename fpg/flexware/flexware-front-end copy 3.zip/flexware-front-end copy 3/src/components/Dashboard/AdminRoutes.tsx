import React, { lazy } from 'react';
import { Switch, Route, match } from 'react-router-dom';

const AdminDashboard = lazy(() =>
  import('./admin/Dashboard/DashboardContainer'),
);
const Clients = lazy(() => import('./admin/Clients'));
const Reports = lazy(() => import('./admin/ReportsContainer'));
const Settings = lazy(() => import('./admin/Settings/SettingsContainer'));

type AdminRoutesType = {
  match: match<{}>;
};

const AdminRoutes = ({ match: routeMatch }: AdminRoutesType) => (
  <Switch>
    <Route path={`${routeMatch.path}/`} exact component={AdminDashboard} />
    <Route path={`${routeMatch.path}/clients`} component={Clients} />
    <Route path={`${routeMatch.path}/reports`} component={Reports} />
    <Route path={`${routeMatch.path}/settings`} component={Settings} />
  </Switch>
);

export default AdminRoutes;
