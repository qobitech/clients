/* eslint-disable import/no-cycle */
import React from 'react';
// import { useSelector } from 'react-redux';
// import { warningDiff } from '../Router';
// import { ReducerTypes } from '../../reducers';

const ActivityTimerContainer: React.FC<{
  // time: number;
  // showTimer: boolean;
  // setShowTimer: (arg?: any) => void;
  // fullTime: number;
  // reset: boolean;
  // getRemainingTime: () => number;
}> = () =>
  // {
  //   //  time: propTime, showTimer, setShowTimer, fullTime, reset
  // },
  {
    // const { app } = useSelector((state: ReducerTypes) => state);
    // const [time, setTime] = useState((fullTime - propTime) / 1000);
    // const [show, setShow] = useState(false);

    // useEffect(() => {
    //   const triggerTimeOut = () => {
    //     return setTimeout(() => {
    //       setShow(true);
    //       setShowTimer(true);
    //       setTime(time - 1);
    //     }, propTime);
    //   };

    //   const t1 = triggerTimeOut();
    //   return () => {
    //     clearTimeout(t1);
    //   };
    // }, [reset, propTime, setShowTimer, time]);

    // if (show) {
    //   if (time <= 0) {
    //     setTime((fullTime - propTime) / 1000);
    //     setShow(false);
    //     setShowTimer(false);
    //   }
    //   setTimeout(() => {
    //     setTime(time - 1);
    //   }, 1000);
    // }

    // useEffect(() => {
    //   setTime((fullTime - propTime) / 1000);
    //   setShow(false);
    //   setShowTimer(false);
    // }, [reset, fullTime, propTime, setShowTimer]);

    return <div />;
  };

export default ActivityTimerContainer;
