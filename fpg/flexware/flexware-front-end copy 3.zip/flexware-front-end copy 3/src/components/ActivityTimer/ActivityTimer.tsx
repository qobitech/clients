import React from 'react';
import Classes from './index.module.css';

const ActivityTimer: React.FC<{
  showModal: boolean;
  handleClose: (arg?: any) => void;
  handleLogout: (arg?: any) => void;
  remainingTime?: number;
}> = ({ showModal }) => {
  return (
    <div className={`${Classes.container} ${!showModal && Classes.hide}`}>
      <div className={Classes.display}>
        <p>Due to inactivity, your session will end soon</p>
        <div
          style={{ display: 'flex', alignItems: 'center', transition: '0.3s' }}
        >
          <h1>time</h1>
          <span style={{ marginLeft: '5px' }}>s</span>
        </div>
      </div>
    </div>
  );
};

export default ActivityTimer;
