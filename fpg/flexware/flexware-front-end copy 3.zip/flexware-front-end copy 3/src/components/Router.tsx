/* eslint-disable react/jsx-props-no-spreading */
/* eslint-disable import/no-cycle */
import React, { Suspense, lazy, useState, useEffect } from 'react';
// import IdleTimer from 'react-idle-timer';
import { useSelector, useDispatch } from 'react-redux';
import { Route, Redirect, RouteProps } from 'react-router-dom';
// import ActivityWrapper from './elements/ActivityWrapper';
// import { setWarningState, logout } from '../actions/app';
import { setVerified, setAuthToken, setUid } from '../actions/user';
// eslint-disable-next-line import/no-cycle
import Auth from './Auth/AuthContainer';
import { ReducerTypes } from '../reducers';
import api from '../utils/api';
import ActivityWrapper from './elements/ActivityWrapper';

const Dashboard = lazy(() => import('./Dashboard/DashboardContainer'));

interface ProtectedRouteProps extends RouteProps {
  auth: boolean;
  to?: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  component: React.ComponentType<any>;
}

const ProtectedRoute = ({
  path,
  component: Comp,
  auth,
  exact,
  to,
  children,
  ...rest
}: ProtectedRouteProps) => {
  return (
    <Suspense fallback={<div>LOADING</div>}>
      <Route
        exact={!!exact}
        to={to}
        path={path}
        // eslint-disable-next-line react/jsx-props-no-spreading
        render={
          (moreProps: RouteProps) =>
            auth ? (
              <Comp {...rest} {...moreProps} />
            ) : (
              <Redirect to={to || '/signin'} />
            )
          // eslint-disable-next-line react/jsx-curly-newline
        }
      >
        {children}
      </Route>
    </Suspense>
  );
};

export const warningDiff = 5000;

const Router = () => {
  const dispatch = useDispatch();
  const {
    user: {
      type,
      //  token,
      verified,
    },
  } = useSelector((state: ReducerTypes) => state);

  // const location = useLocation();
  const [verifyingUser, isVerifying] = useState(false);
  // const [signoutTime] = useState(15000);
  // const [warningTime] = useState(warningDiff);

  // const destroy = () => {
  //   console.log('Session destroyed');
  // };

  // ['load', 'mousemove', 'mousedown', 'click', 'scroll', 'keypress'].forEach(
  //   (i: string) => {
  //     window.addEventListener(i, () => {
  //       // console.log('tomoe', location.pathname);
  //     });
  //   },
  // );

  // useEffect(() => {
  //   let warnTimeout: any;
  //   let logoutTimeout: any;

  //   const warn = () => {
  //     dispatch(setWarningState(true));
  //   };
  //   const end = () => {
  //     dispatch(setWarningState(true));
  //     dispatch(logout());
  //   };
  //   const setTimeouts = () => {
  //     // const aToken = localStorage.getItem('token');
  //     // console.log('tomoe', aToken);
  //     // console.log('tomoe', 'token', token);
  //     console.log('VVV', verified);
  //     if (verified) {
  //       warnTimeout = setTimeout(warn, signoutTime - warningTime);
  //       logoutTimeout = setTimeout(end, signoutTime);
  //     }
  //   };

  //   const clearTimeouts = () => {
  //     if (warnTimeout) clearTimeout(warnTimeout);
  //     if (logoutTimeout) clearTimeout(logoutTimeout);
  //     dispatch(setWarningState(false));
  //   };
  //   const events: string[] = [
  //     'load',
  //     'mousemove',
  //     'mousedown',
  //     'click',
  //     'scroll',
  //     'keypress',
  //   ];
  //   // console.log('TOKE', token);
  //   const resetTimeout = () => {
  //     clearTimeouts();
  //     setTimeouts();
  //   };

  //   events.forEach((i: string) => {
  //     window.addEventListener(i, resetTimeout);
  //   });

  //   setTimeouts();
  //   return () => {
  //     events.forEach((i: string) => {
  //       window.addEventListener(i, resetTimeout);
  //       clearTimeouts();
  //     });
  //   };
  // }, [token, dispatch, signoutTime, warningTime, verified]);

  useEffect(() => {
    if (!verified) {
      const userToken = localStorage.getItem('token');
      const uid = localStorage.getItem('uid');
      const otp = localStorage.getItem('otp');
      if (userToken) {
        setAuthToken(userToken);
      }
      if (uid) {
        setUid(uid);
      }
      // remove if usertoken
      if (userToken) {
        if (otp) {
          isVerifying(true);

          // api
          //   .post('/otp/verify', { otp, userId: uid }, userToken)
          //   .then(data => {
          //     if (!data.error) {
          //       localStorage.removeItem('otp');
          //       dispatch(setVerified(true));
          //       isVerifying(false);
          //     } else {
          //       localStorage.removeItem('otp');
          //       dispatch(setVerified(false));
          //       isVerifying(false);

          //       // sim
          //       // localStorage.removeItem('otp');
          //       // dispatch(setVerified(true));
          //       // isVerifying(false);
          //     }
          //   })
          api
            .get('/otp/check', userToken)
            .then(data => {
              if (data) {
                dispatch(setVerified(true));
                isVerifying(false);
              } else {
                localStorage.removeItem('otp');
                dispatch(setVerified(false));
                isVerifying(false);
              }
            })
            .catch(() => {
              dispatch(setVerified(false));
              isVerifying(false);

              // sim
              // dispatch(setVerified(true));
              // isVerifying(false);
            });
        } else if (verified) {
          dispatch(setVerified(true));

          // sim
          // dispatch(setVerified(true));
        }
        // else {
        //   // remove this else bloack
        //   dispatch(setVerified(true));
        // }
      }
    }
  }, [verified, dispatch]);

  return verifyingUser ? (
    <h1>LOADING</h1>
  ) : (
    <>
      <Route path="/signin" exact component={Auth} auth />

      {/* <ActivityWrapper> */}
      <Route
        path="/signup"
        exact
        render={props => <Auth signup {...props} />}
      />
      <ActivityWrapper>
        <ProtectedRoute
          path={`/${type}/dashboard`}
          component={Dashboard}
          auth={verified}
        />
      </ActivityWrapper>
      <Route path="/" exact component={Auth} />
    </>
  );
};

export default Router;
