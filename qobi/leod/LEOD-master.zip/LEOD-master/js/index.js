// alert('working');
// alert(window.location.href)

document.querySelector('#logForm').addEventListener('submit',(event)=>{
    event.preventDefault();
})


regForm = document.querySelector('#reg');
regForm.addEventListener('submit', (event)=>{
    message = document.querySelector('.message');
    event.preventDefault();
    password = document.querySelector('#password');
    reEnterPassword = document.querySelector('#reEnterPassword');
    if(password.value != reEnterPassword.value){
        message.innerHTML=`${password.name} does not match`;
        reEnterPassword.style.borderBottom=`1px solid red`;
        setTimeout(() => {
            message.innerHTML=``;
            reEnterPassword.style.borderBottom=`1px solid white`;
        }, 3000);
    }else{
        reEnterPassword.style.borderBottom=`1px solid green`;
        setTimeout(()=>{
            reEnterPassword.style.borderBottom=`1px solid white`;
        },3000)
        
    }
}) 