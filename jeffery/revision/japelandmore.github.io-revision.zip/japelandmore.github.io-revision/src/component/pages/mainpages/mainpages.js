import LandingPage from './landingpage';
import Background from './background';
import Articles from './articles';
import Work from './work';
import Contact from './contact';


export {
    LandingPage,
    Background,
    Articles,
    Work,
    Contact
}