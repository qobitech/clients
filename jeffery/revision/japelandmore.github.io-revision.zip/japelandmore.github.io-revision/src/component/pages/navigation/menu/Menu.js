import React from 'react';
import MenuCss from './Menu.module.css'


const Menu = () => {

    return(

        <div className={MenuCss.Menu}>
            
        </div>

    )
}

export default Menu;

