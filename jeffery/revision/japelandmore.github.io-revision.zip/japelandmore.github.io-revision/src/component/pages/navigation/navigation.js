import Header from './header';
import Footer from './footer';
import Menu from './menu';
import SideMenu from './sidemenu'

export {
    Header,
    Footer,
    Menu,
    SideMenu
}